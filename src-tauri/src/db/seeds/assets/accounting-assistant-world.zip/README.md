# 记账助手世界包

一个单智能体、无模型调用的本地记账世界包。桌面与 Android 分别使用一份完整的 HTML 界面，录入、编辑、删除、筛选和统计都不会进入模型回合。

## 界面

- 桌面：左侧导航 + 账册工作区，包含总览、明细、记一笔、设置。
- 移动：独立底部页签布局，表单与明细针对窄屏重排。
- 数据通过 `world.records` 读写 `ledger.entries`，预算与默认账户通过 `world.kv` 保存在 `ledger.preferences`。
- 所有金额以整数“分”保存，显示时使用人民币格式。

## 构建

`ui.ts` 是共享交互源码，`ui.desktop.css` / `ui.mobile.css` 是两端样式源：

```powershell
cd E:\code\rustweb
node scripts/build-assistant-world-ui.mjs accounting-assistant
python scripts/pack_world_zip.py accounting-assistant
```

产物：`output/accounting-assistant-world.zip`。

## 依赖

- 世界包格式 version 10
- UI runtime version 3
- `storage.collections.ledger.entries` 账单集合及字段约束
- `supports_world_records` + `supports_world_storage`
- `ui_capabilities` 中的旧版兼容标记保留，但界面不再使用 `ledger_book` 注册组件

## 数据语义

- 账单按导入后生成的 `world_id` 隔离在 `ledger.entries` collection 中。
- 账单不写入世界包，也不随存档分支复制；删除单个游戏存档不会删除账本。
- 删除整个世界时，对应账单由宿主数据库外键级联清理。
- 导出世界包只导出定义和界面，不导出用户账单。
- 世界包只能通过 `world.records` / `world.kv` 请求宿主执行类型化操作，不直接访问 SQLite、文件系统或 Tauri 命令。
