// Authoring source. scripts/build-assistant-world-ui.mjs embeds the compiled JS in both HTML entries.
type Snapshot = {
  world?: { name?: string };
  session?: { time_label?: string | null };
  errors?: { action_error?: string | null; page_error?: string | null };
  ui_state?: { loading?: boolean };
};
type Entry = {
  schema_version: 1;
  kind: 'income' | 'expense';
  amount_cents: number;
  date: string;
  category: string;
  account: string;
  note: string;
};
type RecordRow = { id: string; data: Entry; created_at?: string; updated_at?: string };
type WorldSdk = {
  getState(): Snapshot;
  subscribe(listener: (state: Snapshot) => void): () => void;
  records: {
    list(collection: string): Promise<unknown>;
    create(collection: string, data: unknown): Promise<unknown>;
    update(collection: string, recordId: string, data: unknown): Promise<unknown>;
    delete(collection: string, recordId: string): Promise<unknown>;
  };
  kv: {
    get(namespace: string, key: string): Promise<unknown>;
    set(namespace: string, key: string, value: unknown): Promise<unknown>;
  };
  actions: {
    navigate(target: string): Promise<unknown>;
  };
};

const world = (window as unknown as { world: WorldSdk }).world;
const $ = <T extends HTMLElement = HTMLElement>(id: string) => document.getElementById(id) as T | null;
const qs = <T extends HTMLElement = HTMLElement>(selector: string) => document.querySelector(selector) as T | null;
const qsa = <T extends HTMLElement = HTMLElement>(selector: string) => Array.from(document.querySelectorAll(selector)) as T[];
const el = <K extends keyof HTMLElementTagNameMap>(tag: K, className = '', text = '') => {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text) node.textContent = text;
  return node;
};

const COLLECTION = 'ledger.entries';
const PREFERENCES = 'ledger.preferences';
const STANDARD_CATEGORIES = ['餐饮', '交通', '购物', '居住', '医疗', '娱乐', '学习', '人情', '工资', '理财', '其他'];
const DEFAULT_ACCOUNT = '日常账户';
const money = new Intl.NumberFormat('zh-CN', { style: 'currency', currency: 'CNY' });
const plainNumber = new Intl.NumberFormat('zh-CN', { maximumFractionDigits: 2 });

let state: Snapshot = {};
let rows: RecordRow[] = [];
let view = 'overview';
let month = localMonth(new Date());
let budget = 0;
let defaultAccount = DEFAULT_ACCOUNT;
let editingId = '';
let loading = false;
let localError = '';
let toastTimer = 0;
let filterKind = 'all';
let filterCategory = 'all';
let filterSearch = '';
let hydrated = false;

function localDate(date = new Date()) {
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}
function localMonth(date = new Date()) {
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}`;
}
function pad(value: number) {
  return String(value).padStart(2, '0');
}
function parseMonth(value: string) {
  const [year, monthNumber] = value.split('-').map(Number);
  return new Date(year, (monthNumber || 1) - 1, 1);
}
function shiftMonth(delta: number) {
  const date = parseMonth(month);
  date.setMonth(date.getMonth() + delta);
  month = localMonth(date);
}
function formatMonth(value: string) {
  const date = parseMonth(value);
  return `${date.getFullYear()} 年 ${date.getMonth() + 1} 月`;
}
function formatDateLabel(value: string) {
  const date = new Date(`${value}T00:00:00`);
  if (Number.isNaN(date.getTime())) return value;
  const week = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][date.getDay()];
  return `${date.getMonth() + 1} 月 ${date.getDate()} 日 · ${week}`;
}
function amountOf(row: RecordRow) {
  return Math.max(0, Math.round(Number(row.data.amount_cents) || 0));
}
function signed(row: RecordRow) {
  return `${row.data.kind === 'income' ? '+' : '−'}${money.format(amountOf(row) / 100)}`;
}
function errorText(error: unknown) {
  return error instanceof Error ? error.message : String(error);
}
function setBanner(message = '') {
  const banner = $('banner')!;
  banner.textContent = message;
  banner.hidden = !message;
  banner.classList.toggle('has-error', Boolean(message));
}
function toast(message: string) {
  const node = $('toast');
  if (!node) return;
  node.textContent = message;
  node.classList.add('show');
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => node.classList.remove('show'), 2200);
}
function run(work: () => Promise<unknown>) {
  void work().catch((error) => {
    localError = errorText(error);
    setBanner(localError);
  });
}
function unwrap(value: unknown) {
  if (value && typeof value === 'object' && 'value' in (value as Record<string, unknown>)) {
    return (value as Record<string, unknown>).value;
  }
  return value;
}
function normalizeRows(value: unknown): RecordRow[] {
  const raw = Array.isArray(value)
    ? value
    : value && typeof value === 'object' && Array.isArray((value as { records?: unknown }).records)
      ? (value as { records: unknown[] }).records
      : [];
  const result: RecordRow[] = [];
  for (const item of raw) {
    if (!item || typeof item !== 'object') continue;
    const source = item as Record<string, unknown>;
    const data = source.data && typeof source.data === 'object' ? source.data as Record<string, unknown> : source;
    const kind = data.kind === 'income' ? 'income' : 'expense';
    const entry: Entry = {
      schema_version: 1,
      kind,
      amount_cents: Math.max(0, Math.round(Number(data.amount_cents) || 0)),
      date: String(data.date || '').slice(0, 10),
      category: String(data.category || '其他'),
      account: String(data.account || DEFAULT_ACCOUNT),
      note: String(data.note || ''),
    };
    if (!entry.date || !entry.amount_cents) continue;
    result.push({
      id: String(source.id || source.record_id || source.recordId || ''),
      data: entry,
      created_at: typeof source.created_at === 'string' ? source.created_at : undefined,
      updated_at: typeof source.updated_at === 'string' ? source.updated_at : undefined,
    });
  }
  return result.sort((a, b) => (a.data.date === b.data.date ? b.id.localeCompare(a.id) : b.data.date.localeCompare(a.data.date)));
}
function recordsForMonth() {
  return rows.filter((row) => row.data.date.startsWith(month));
}
function categoryOptions() {
  const set = new Set(STANDARD_CATEGORIES);
  for (const row of rows) if (row.data.category) set.add(row.data.category);
  return Array.from(set);
}
function fillSelect(select: HTMLSelectElement, values: string[], allLabel?: string) {
  const previous = select.value;
  select.replaceChildren();
  if (allLabel) {
    const all = el('option', '', allLabel);
    all.value = 'all';
    select.append(all);
  }
  for (const value of values) {
    const option = el('option', '', value);
    option.value = value;
    select.append(option);
  }
  if (Array.from(select.options).some((option) => option.value === previous)) select.value = previous;
}
function switchView(next: string) {
  view = next;
  for (const section of qsa<HTMLElement>('[data-view-panel]')) section.hidden = section.dataset.viewPanel !== next;
  for (const button of qsa<HTMLElement>('[data-view]')) {
    const active = button.dataset.view === next;
    button.classList.toggle('is-active', active);
    button.setAttribute('aria-current', active ? 'page' : 'false');
  }
  const title = $('page-title');
  if (title) title.textContent = { overview: '总览', ledger: '明细', add: editingId ? '编辑记录' : '记一笔', settings: '设置' }[next] || '总览';
  if (next === 'settings') renderSettings();
  if (next === 'ledger') renderLedger();
}
function setLoading(value: boolean) {
  loading = value;
  for (const node of qsa<HTMLElement>('[data-loading]')) node.hidden = !value;
  for (const node of qsa<HTMLElement>('[data-content]')) node.hidden = value;
}
async function loadPreferences() {
  try {
    const savedBudget = Number(unwrap(await world.kv.get(PREFERENCES, 'monthly_budget_cents')));
    budget = Number.isFinite(savedBudget) && savedBudget > 0 ? Math.round(savedBudget) : 0;
    const savedAccount = String(unwrap(await world.kv.get(PREFERENCES, 'default_account')) || '');
    defaultAccount = savedAccount || DEFAULT_ACCOUNT;
  } catch {
    budget = 0;
    defaultAccount = DEFAULT_ACCOUNT;
  }
  const accountInput = $<HTMLInputElement>('entry-account');
  if (accountInput && !accountInput.value) accountInput.value = defaultAccount;
  const budgetInput = $<HTMLInputElement>('budget-input');
  if (budgetInput) budgetInput.value = budget ? String(budget / 100) : '';
  const defaultInput = $<HTMLInputElement>('default-account-input');
  if (defaultInput) defaultInput.value = defaultAccount;
}
async function loadRecords() {
  setLoading(true);
  setBanner('');
  try {
    rows = normalizeRows(await world.records.list(COLLECTION));
    renderAll();
  } catch (error) {
    localError = errorText(error);
    setBanner(localError);
  } finally {
    setLoading(false);
  }
}
function renderAll() {
  renderChrome();
  renderOverview();
  renderLedger();
  renderSettings();
}
function renderChrome() {
  const label = $('month-label');
  if (label) label.textContent = formatMonth(month);
  const worldName = $('world-name');
  if (worldName) worldName.textContent = state.world?.name || '记账助手';
  const accountInput = $<HTMLInputElement>('entry-account');
  if (accountInput && !accountInput.value) accountInput.value = defaultAccount;
}
function renderOverview() {
  const monthRows = recordsForMonth();
  let income = 0;
  let expense = 0;
  const categories = new Map<string, number>();
  for (const row of monthRows) {
    const amount = amountOf(row);
    if (row.data.kind === 'income') income += amount;
    else {
      expense += amount;
      categories.set(row.data.category, (categories.get(row.data.category) || 0) + amount);
    }
  }
  const balance = income - expense;
  const setMetric = (id: string, value: string, note: string) => {
    const node = $(id);
    if (node) node.textContent = value;
    const noteNode = $(`${id}-note`);
    if (noteNode) noteNode.textContent = note;
  };
  setMetric('metric-income', money.format(income / 100), `${monthRows.filter((row) => row.data.kind === 'income').length} 笔收入`);
  setMetric('metric-expense', money.format(expense / 100), `${monthRows.filter((row) => row.data.kind === 'expense').length} 笔支出`);
  setMetric('metric-balance', money.format(balance / 100), balance >= 0 ? '本月结余' : '本月超支');
  const balanceNode = $('metric-balance');
  if (balanceNode) balanceNode.classList.toggle('is-negative', balance < 0);
  const budgetNote = $('budget-note');
  if (budgetNote) {
    budgetNote.textContent = budget > 0
      ? `本月预算 ${money.format(budget / 100)}，剩余 ${money.format(Math.max(0, budget - expense) / 100)}`
      : '还没有设置本月预算，可在设置里补充。';
  }
  const gauge = $('budget-gauge');
  if (gauge) {
    const ratio = budget > 0 ? Math.min(100, expense / budget * 100) : 0;
    gauge.style.setProperty('--value', `${ratio}%`);
    gauge.classList.toggle('is-over', budget > 0 && expense > budget);
    gauge.setAttribute('aria-valuenow', String(Math.round(ratio)));
  }

  const chart = $('category-chart');
  if (chart) {
    chart.replaceChildren();
    const list = Array.from(categories.entries()).sort((a, b) => b[1] - a[1]).slice(0, 6);
    const empty = $('category-empty');
    if (empty) empty.hidden = list.length > 0;
    const max = list.length ? list[0][1] : 1;
    for (const [name, amount] of list) {
      const item = el('div', 'category-row');
      const head = el('div', 'category-head');
      head.append(el('span', 'category-name', name));
      head.append(el('span', 'category-amount', money.format(amount / 100)));
      const track = el('div', 'bar-track');
      const bar = el('i', 'bar-fill');
      bar.style.width = `${Math.max(3, amount / max * 100)}%`;
      track.append(bar);
      item.append(head, track);
      chart.append(item);
    }
  }

  const recent = $('recent-list');
  if (recent) {
    recent.replaceChildren();
    const list = rows.slice(0, 6);
    const empty = $('recent-empty');
    if (empty) empty.hidden = list.length > 0;
    for (const row of list) recent.append(recordRow(row));
  }
  renderCounts();
}
function renderCounts() {
  const count = $('record-count');
  if (count) count.textContent = `${rows.length} 条记录`;
  const settingsCount = $('settings-count');
  if (settingsCount) settingsCount.textContent = `${rows.length} 条记录保存在本地世界存储中`;
}
function recordRow(row: RecordRow, compact = false) {
  const item = el('article', `record${compact ? ' record--compact' : ''}${row.data.kind === 'income' ? ' record--income' : ''}`);
  const main = el('div', 'record-main');
  const title = el('div', 'record-title');
  title.append(el('strong', '', row.data.category || '未分类'));
  title.append(el('span', 'record-account', row.data.account || DEFAULT_ACCOUNT));
  main.append(title);
  if (row.data.note) main.append(el('p', 'record-note', row.data.note));
  main.append(el('time', 'record-date', formatDateLabel(row.data.date)));
  const side = el('div', 'record-side');
  side.append(el('strong', 'record-amount', signed(row)));
  item.append(main, side);
  const actions = el('div', 'record-actions');
  const edit = el('button', 'ghost-button', '编辑');
  edit.type = 'button';
  edit.dataset.edit = row.id;
  const remove = el('button', 'ghost-button danger', '删除');
  remove.type = 'button';
  remove.dataset.delete = row.id;
  actions.append(edit, remove);
  item.append(actions);
  return item;
}
function renderLedger() {
  if (!hydrated) return;
  const categories = $<HTMLSelectElement>('filter-category');
  if (categories) fillSelect(categories, categoryOptions(), '全部分类');
  if (categories && filterCategory !== 'all') categories.value = filterCategory;
  const kind = $<HTMLSelectElement>('filter-kind');
  if (kind) kind.value = filterKind;
  const search = $<HTMLInputElement>('filter-search');
  if (search && search.value !== filterSearch) search.value = filterSearch;
  const list = $('ledger-list');
  if (!list) return;
  list.replaceChildren();
  const filtered = recordsForMonth().filter((row) => {
    if (filterKind !== 'all' && row.data.kind !== filterKind) return false;
    if (filterCategory !== 'all' && row.data.category !== filterCategory) return false;
    if (filterSearch) {
      const haystack = `${row.data.category} ${row.data.account} ${row.data.note}`.toLowerCase();
      if (!haystack.includes(filterSearch.toLowerCase())) return false;
    }
    return true;
  });
  const empty = $('ledger-empty');
  if (empty) empty.hidden = filtered.length > 0;
  const count = $('ledger-count');
  if (count) count.textContent = `${filtered.length} 笔`;
  let currentDate = '';
  for (const row of filtered) {
    if (row.data.date !== currentDate) {
      currentDate = row.data.date;
      const heading = el('div', 'date-heading');
      heading.append(el('span', '', formatDateLabel(currentDate)));
      let dayTotal = 0;
      for (const item of filtered) if (item.data.date === currentDate) dayTotal += item.data.kind === 'expense' ? amountOf(item) : -amountOf(item);
      const net = el('strong', dayTotal > 0 ? 'is-negative' : '', dayTotal === 0 ? '' : `${dayTotal > 0 ? '−' : '+'}${money.format(Math.abs(dayTotal) / 100)}`);
      heading.append(net);
      list.append(heading);
    }
    list.append(recordRow(row));
  }
}
function renderSettings() {
  const count = $('settings-count');
  if (count) count.textContent = `${rows.length} 条记录保存在本地世界存储中`;
  const budgetInput = $<HTMLInputElement>('budget-input');
  if (budgetInput && document.activeElement !== budgetInput) budgetInput.value = budget ? String(budget / 100) : '';
  const defaultInput = $<HTMLInputElement>('default-account-input');
  if (defaultInput && document.activeElement !== defaultInput) defaultInput.value = defaultAccount;
  const storage = $('storage-note');
  if (storage) storage.textContent = state.session?.time_label ? `世界时间：${state.session.time_label}` : '数据只保存在当前世界的本地存储中。';
}
function setKind(kind: 'income' | 'expense') {
  for (const button of qsa<HTMLElement>('[data-kind]')) {
    const active = button.dataset.kind === kind;
    button.classList.toggle('is-active', active);
    button.setAttribute('aria-pressed', String(active));
  }
  const label = $('amount-label');
  if (label) label.textContent = kind === 'income' ? '收入金额' : '支出金额';
}
function currentKind(): 'income' | 'expense' {
  return qs<HTMLElement>('[data-kind].is-active')?.dataset.kind === 'income' ? 'income' : 'expense';
}
function resetForm() {
  editingId = '';
  const amount = $<HTMLInputElement>('entry-amount');
  const date = $<HTMLInputElement>('entry-date');
  const category = $<HTMLSelectElement>('entry-category');
  const account = $<HTMLInputElement>('entry-account');
  const note = $<HTMLTextAreaElement>('entry-note');
  if (amount) amount.value = '';
  if (date) date.value = localDate();
  if (category) category.value = '餐饮';
  if (account) account.value = defaultAccount;
  if (note) note.value = '';
  setKind('expense');
  const submit = $('entry-submit');
  if (submit) submit.textContent = '保存这笔';
  const cancel = $('entry-cancel-edit');
  if (cancel) cancel.hidden = true;
  const error = $('form-error');
  if (error) error.hidden = true;
  const title = $('page-title');
  if (title && view === 'add') title.textContent = '记一笔';
}
function fillForm(row: RecordRow) {
  editingId = row.id;
  setKind(row.data.kind);
  const amount = $<HTMLInputElement>('entry-amount');
  const date = $<HTMLInputElement>('entry-date');
  const category = $<HTMLSelectElement>('entry-category');
  const account = $<HTMLInputElement>('entry-account');
  const note = $<HTMLTextAreaElement>('entry-note');
  if (amount) amount.value = (row.data.amount_cents / 100).toFixed(2).replace(/\.00$/, '');
  if (date) date.value = row.data.date;
  if (category) category.value = row.data.category;
  if (account) account.value = row.data.account;
  if (note) note.value = row.data.note;
  const submit = $('entry-submit');
  if (submit) submit.textContent = '保存修改';
  const cancel = $('entry-cancel-edit');
  if (cancel) cancel.hidden = false;
  switchView('add');
  $<HTMLInputElement>('entry-amount')?.focus();
}
async function saveEntry() {
  const error = $('form-error');
  if (error) error.hidden = true;
  const amountValue = String($<HTMLInputElement>('entry-amount')?.value || '').trim().replace(/,/g, '');
  const amount = Number(amountValue);
  const cents = Math.round(amount * 100);
  if (!amountValue || !Number.isFinite(amount) || cents < 1) {
    if (error) { error.textContent = '请输入大于 0 的金额。'; error.hidden = false; }
    return;
  }
  if (cents > 99999999999) {
    if (error) { error.textContent = '金额超出可记录范围。'; error.hidden = false; }
    return;
  }
  const date = String($<HTMLInputElement>('entry-date')?.value || '').slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    if (error) { error.textContent = '请选择有效日期。'; error.hidden = false; }
    return;
  }
  const entry: Entry = {
    schema_version: 1,
    kind: currentKind(),
    amount_cents: cents,
    date,
    category: String($<HTMLSelectElement>('entry-category')?.value || '其他') || '其他',
    account: String($<HTMLInputElement>('entry-account')?.value || '').trim() || defaultAccount,
    note: String($<HTMLTextAreaElement>('entry-note')?.value || '').trim().slice(0, 500),
  };
  const submit = $<HTMLButtonElement>('entry-submit');
  if (submit) submit.disabled = true;
  try {
    if (editingId) {
      await world.records.update(COLLECTION, editingId, entry);
      const index = rows.findIndex((row) => row.id === editingId);
      if (index >= 0) rows[index] = { ...rows[index], data: entry };
      toast('记录已更新');
    } else {
      await world.records.create(COLLECTION, entry);
      toast('已记入账本');
    }
    rows = normalizeRows(await world.records.list(COLLECTION));
    month = entry.date.slice(0, 7);
    resetForm();
    renderAll();
    switchView('ledger');
  } catch (failure) {
    const message = errorText(failure);
    if (error) { error.textContent = message; error.hidden = false; }
    setBanner(message);
  } finally {
    if (submit) submit.disabled = false;
  }
}
function openDelete(row: RecordRow) {
  const root = $('dialog-root');
  if (!root) return;
  root.replaceChildren();
  root.hidden = false;
  const panel = el('section', 'dialog');
  panel.setAttribute('role', 'dialog');
  panel.setAttribute('aria-modal', 'true');
  panel.setAttribute('aria-labelledby', 'delete-title');
  panel.append(el('p', 'eyebrow', '删除记录'));
  const title = el('h2', '', '确认删除这笔记录？');
  title.id = 'delete-title';
  panel.append(title);
  const summary = el('div', 'dialog-summary');
  summary.append(el('strong', '', `${row.data.category} · ${signed(row)}`));
  summary.append(el('span', '', `${formatDateLabel(row.data.date)}${row.data.note ? ` · ${row.data.note}` : ''}`));
  panel.append(summary);
  panel.append(el('p', 'dialog-copy', '删除后无法从账本恢复，但不会影响其他记录。'));
  const actions = el('div', 'dialog-actions');
  const cancel = el('button', 'ghost-button', '取消');
  cancel.type = 'button';
  cancel.onclick = () => closeDialog();
  const remove = el('button', 'danger-button', '删除');
  remove.type = 'button';
  remove.onclick = () => run(async () => {
    remove.disabled = true;
    await world.records.delete(COLLECTION, row.id);
    rows = rows.filter((item) => item.id !== row.id);
    closeDialog();
    renderAll();
    toast('记录已删除');
  });
  actions.append(cancel, remove);
  panel.append(actions);
  root.append(panel);
  cancel.focus();
}
function closeDialog() {
  const root = $('dialog-root');
  if (!root) return;
  root.hidden = true;
  root.replaceChildren();
}
function saveSettings() {
  const budgetValue = Number($<HTMLInputElement>('budget-input')?.value || 0);
  const nextBudget = Number.isFinite(budgetValue) && budgetValue > 0 ? Math.round(budgetValue * 100) : 0;
  const nextAccount = String($<HTMLInputElement>('default-account-input')?.value || '').trim().slice(0, 80) || DEFAULT_ACCOUNT;
  run(async () => {
    await world.kv.set(PREFERENCES, 'monthly_budget_cents', nextBudget);
    await world.kv.set(PREFERENCES, 'default_account', nextAccount);
    budget = nextBudget;
    defaultAccount = nextAccount;
    const accountInput = $<HTMLInputElement>('entry-account');
    if (accountInput && !accountInput.value) accountInput.value = defaultAccount;
    renderOverview();
    renderSettings();
    toast('设置已保存');
  });
}
function hydrateControls() {
  for (const button of qsa<HTMLElement>('[data-view]')) {
    button.addEventListener('click', () => switchView(button.dataset.view || 'overview'));
  }
  for (const button of qsa<HTMLElement>('[data-month]')) {
    button.addEventListener('click', () => {
      shiftMonth(button.dataset.month === 'next' ? 1 : -1);
      renderAll();
    });
  }
  for (const button of qsa<HTMLElement>('[data-kind]')) {
    button.addEventListener('click', () => setKind(button.dataset.kind === 'income' ? 'income' : 'expense'));
  }
  $('quick-add')?.addEventListener('click', () => { resetForm(); switchView('add'); });
  $('back')?.addEventListener('click', () => run(() => world.actions.navigate('home')));
  $('empty-add')?.addEventListener('click', () => { resetForm(); switchView('add'); });
  $('entry-submit')?.addEventListener('click', () => run(saveEntry));
  $('entry-cancel-edit')?.addEventListener('click', () => { resetForm(); switchView('ledger'); });
  $('settings-save')?.addEventListener('click', saveSettings);
  $('dialog-root')?.addEventListener('click', (event) => { if (event.target === $('dialog-root')) closeDialog(); });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') closeDialog();
  });
  $('filter-kind')?.addEventListener('change', (event) => {
    filterKind = (event.currentTarget as HTMLSelectElement).value;
    renderLedger();
  });
  $('filter-category')?.addEventListener('change', (event) => {
    filterCategory = (event.currentTarget as HTMLSelectElement).value;
    renderLedger();
  });
  $('filter-search')?.addEventListener('input', (event) => {
    filterSearch = (event.currentTarget as HTMLInputElement).value.trim();
    renderLedger();
  });
  const list = $('ledger-list');
  list?.addEventListener('click', (event) => {
    const target = event.target as HTMLElement;
    const edit = target.closest<HTMLElement>('[data-edit]');
    if (edit) {
      const row = rows.find((item) => item.id === edit.dataset.edit);
      if (row) fillForm(row);
      return;
    }
    const remove = target.closest<HTMLElement>('[data-delete]');
    if (remove) {
      const row = rows.find((item) => item.id === remove.dataset.delete);
      if (row) openDelete(row);
    }
  });
  $('recent-list')?.addEventListener('click', (event) => {
    const target = event.target as HTMLElement;
    const edit = target.closest<HTMLElement>('[data-edit]');
    if (edit) {
      const row = rows.find((item) => item.id === edit.dataset.edit);
      if (row) fillForm(row);
      return;
    }
    const remove = target.closest<HTMLElement>('[data-delete]');
    if (remove) {
      const row = rows.find((item) => item.id === remove.dataset.delete);
      if (row) openDelete(row);
    }
  });
  const date = $<HTMLInputElement>('entry-date');
  if (date && !date.value) date.value = localDate();
  const category = $<HTMLSelectElement>('entry-category');
  if (category) fillSelect(category, STANDARD_CATEGORIES);
  setKind('expense');
  switchView('overview');
}
function boot() {
  hydrateControls();
  world.subscribe((next) => {
    state = next;
    renderChrome();
    if (next.errors?.action_error || next.errors?.page_error) {
      localError = next.errors.action_error || next.errors.page_error || '';
      setBanner(localError);
    }
    if (!hydrated) {
      hydrated = true;
      void loadPreferences().then(loadRecords);
    }
  });
}

boot();
