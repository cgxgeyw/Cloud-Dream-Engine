# 凡人修仙：小石村问道

这是一个从七玄门入门试炼开始的《凡人修仙传》人界篇早期同人世界包。玩家扮演原创角色陆谨，与同期的韩立、张铁一起进入七玄门，在凡人江湖与修仙界的边缘谨慎求生。

## 内容

- 桌面端三栏 HTML 叙事界面，右侧标签展示拓扑地图、背包和持久化属性。地图按会话的节点和边绘制，支持平移、缩放与适应视图。
- 移动端安全区布局，地图、背包、装备、功法和修炼状态集中在行囊抽屉。
- 早期地图：镜州、小石村、彩霞山、七玄门山门、炼骨崖、外门弟子院、神手谷、百锻堂、野狼帮山道、太南小会。
- `attribute_schemas` 用 `world` scope 声明世界时间，用 `character` scope 声明角色气血、体力、灵力、装备、功法和修炼等权威状态；新存档自动投影初始化。
- 世界主控通过 `session_attribute_updates` 推进世界时间，通过 `character_attribute_updates` 更新角色状态；背包、地图位置和在场人物使用框架原生会话状态，不建立 KV 副本。
- 主控的选择、确认和滑条交互直接显示在叙事流中，玩家回答后由宿主提交为下一条行动。
- 界面不捆绑背景图；作者可后续向 `manifest.assets` 和 `ui_assets_config.local_scene_backgrounds` 增加自己的场景资源。

## 导入与制作

使用支持 HTML UI 的新版应用导入 `output/mortal-cultivation-journey-world.zip`。包格式为 10，UI runtime 为 3，不依赖世界逻辑脚本或世界 KV。

`ui.ts` 是桌面和移动端共用的 TypeScript 交互源码，`ui.css` 为 HTML 运行时补充样式。运行 `node scripts/build-mortal-world-ui.mjs` 会先检查类型，再将编译后的 JS 和样式嵌入两份 HTML。应用直接加载 HTML，玩家无需安装 TypeScript。

运行 `python scripts/pack_mortal_world.py` 可重新构建并打包；运行 `node scripts/test-mortal-html-ui.mjs` 可在真实 Chromium 隔离 iframe 中验证地图、标签、原生交互回答、发送和失败提示。此测试用模拟宿主处理动作，不调用真实模型。

发送通过按钮显式调用 `world.actions.submitMessage()`，不依赖被沙箱禁止的原生表单提交。失败时保留输入并展示错误，不能把请求返回当作必然成功。
