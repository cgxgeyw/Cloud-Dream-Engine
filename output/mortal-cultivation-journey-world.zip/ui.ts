// Authoring source. scripts/build-mortal-world-ui.mjs embeds the compiled JS in both HTML entries.
import type { GameUiRuntimeSnapshot } from '../../../frontend/src/worldFrame/runtimeSnapshot';
import type { SubmitActionOptions, RenderChatMessage } from '../../../frontend/src/game/utils';

type Snapshot = Partial<GameUiRuntimeSnapshot> & { preview?: boolean };
type Actions = {
  submitMessage(options: SubmitActionOptions): Promise<unknown>;
  switchSideTab(key: string): Promise<unknown>;
  navigate(target: string): Promise<unknown>;
  copyText(text: string): Promise<unknown>;
  branch(): Promise<unknown>;
  editTurn(content: string, turnIndex: number): Promise<unknown>;
  cancelEdit(): Promise<unknown>;
  clearError(): Promise<unknown>;
  pickImage(): Promise<unknown>;
  startRecording(): Promise<unknown>;
  stopRecording(send?: boolean): Promise<unknown>;
  removeImage(index: number): Promise<unknown>;
  removeAudio(index: number): Promise<unknown>;
  answerInteraction(messageId: string, interactionId: string, answer: unknown): Promise<unknown>;
};
const world = (window as unknown as { world: { subscribe(fn: (s: Snapshot) => void): void; actions: Actions } }).world;
const $ = <T extends HTMLElement = HTMLElement>(id: string) => document.getElementById(id) as T | null;
const input = $<HTMLTextAreaElement>('input')!;
const messages = $('messages')!;
const status = $('status')!;
const send = $<HTMLButtonElement>('send')!;
let state: Snapshot = {}, sending = false, localError = '', draftDirty = false, forceFollow = false;
let ledgerKey = '', messagesKey = '', tabsKey = '', editingTurn: number | undefined;
const expanded = new Set<string>();
const answeringInteractions = new Set<string>();
const valueText = (value: unknown): string => typeof value === 'string' ? value : value == null ? '' : JSON.stringify(value);
const messageText = (m: RenderChatMessage): string => typeof m.content === 'string' ? m.content : m.content.filter(p => p.type === 'text').map(p => p.text).join('\n');
const el = <K extends keyof HTMLElementTagNameMap>(tag: K, className = '', text = '') => {
  const node = document.createElement(tag); node.className = className; node.textContent = text; return node;
};
const setText = (id: string, text: string) => { const node = $(id); if (node) node.textContent = text; };
function errorText(error: unknown) { return error instanceof Error ? error.message : String(error); }
function showError(error: unknown) { localError = errorText(error); updateStatus(); }
function run(work: () => Promise<unknown>) { void work().catch(showError); }
function updateStatus() {
  const error = localError || state.errors?.action_error || state.ui_state?.page_error;
  status.textContent = error || (sending || state.ui_state?.submitting ? '正在推进局势…' : state.preview ? '界面预览，尚未进入游戏。' : '');
  status.setAttribute('role', error ? 'alert' : 'status');
  status.classList.toggle('has-error', Boolean(error));
  send.disabled = sending || !!state.ui_state?.submitting;
  send.textContent = sending || state.ui_state?.submitting ? '进行中…' : state.editing ? '保存并重演' : '行动';
}
async function submit(options?: SubmitActionOptions) {
  if (sending || state.ui_state?.submitting) { showError('上一条行动仍在处理，请稍候。'); return; }
  const content = options?.content ?? input.value.trim();
  if (!content && !state.draft_input?.images.length && !state.draft_input?.audios.length) { showError('请输入行动或添加附件。'); return; }
  sending = true; localError = ''; updateStatus();
  forceFollow = true;
  try {
    await world.actions.clearError();
    await world.actions.submitMessage({ content, mode: options?.mode ?? (state.editing ? 'edit' : 'submit'), turnIndex: options?.turnIndex ?? state.editing?.turnIndex });
    if (!options && input.value.trim() === content) { input.value = ''; draftDirty = false; }
  } catch (error) { showError(error); }
  finally { sending = false; updateStatus(); }
}
// No native form submission: sandbox intentionally does not grant allow-forms.
send.type = 'button';
send.onclick = () => void submit();
$('composer')!.onsubmit = event => { event.preventDefault(); void submit(); };
input.oninput = () => { draftDirty = true; };
input.onkeydown = event => {
  if (event.key === 'Enter' && !event.shiftKey && !event.isComposing && document.body.dataset.platform !== 'mobile') {
    event.preventDefault(); void submit();
  }
};
window.addEventListener('world-error', event => showError((event as CustomEvent<{ message: string }>).detail.message));
for (const target of ['home', 'settings', 'debug']) {
  const button = $(target === 'home' ? 'back' : target);
  if (button) button.onclick = () => run(() => world.actions.navigate(target));
}
if ($('attach')) $('attach')!.onclick = () => run(() => world.actions.pickImage());
if ($('voice')) $('voice')!.onclick = () => run(() => state.draft_input?.is_recording ? world.actions.stopRecording() : world.actions.startRecording());
if ($('cancel-edit')) $('cancel-edit')!.onclick = () => run(() => world.actions.cancelEdit());

function renderTabs(s: Snapshot) {
  const signature = JSON.stringify([s.side_tabs, s.active_side_tab]);
  if (signature === tabsKey) return; tabsKey = signature;
  const root = $('tabs')!; const scrollLeft = root.scrollLeft; root.replaceChildren();
  for (const tab of s.side_tabs || []) {
    const button = el('button', 'button' + (tab.key === s.active_side_tab ? ' active' : ''), tab.label);
    button.type = 'button'; button.setAttribute('aria-selected', String(tab.key === s.active_side_tab));
    button.onclick = () => run(() => world.actions.switchSideTab(tab.key)); root.append(button);
  }
  root.scrollLeft = scrollLeft;
}

function renderLedger(s: Snapshot) {
  const signature = JSON.stringify([s.active_side_tab, s.map_graph, s.active_attribute_items, s.active_attribute_content]);
  if (signature === ledgerKey) return; ledgerKey = signature;
  const root = $('ledger-content')!; root.replaceChildren();
  if (s.active_side_tab === 'map') { renderMap(root, s.map_graph); return; }
  if (!s.active_attribute_items?.length) {
    root.append(el('div', 'attribute-text', s.active_attribute_content || '此处暂时没有可展示的状态。')); return;
  }
  for (const item of s.active_attribute_items) {
    const section = el('section', 'attribute');
    const head = el('div', 'attribute-head'); head.append(el('span', '', item.label || item.key));
    if (item.display_policy.presentation === 'meter' && typeof item.value === 'number') {
      const maximum = Number(item.display_policy.max) || 100;
      head.append(el('b', '', `${item.value} / ${maximum}`)); section.append(head);
      const meter = el('div', 'meter'); meter.setAttribute('role', 'meter');
      meter.setAttribute('aria-label', item.label); meter.setAttribute('aria-valuenow', String(item.value)); meter.setAttribute('aria-valuemax', String(maximum));
      const fill = el('i'); fill.style.width = Math.max(0, Math.min(100, item.value / maximum * 100)) + '%';
      meter.append(fill); section.append(meter);
    } else {
      section.append(head);
      if (Array.isArray(item.value)) {
        const list = el('div', 'list'); for (const v of item.value) list.append(el('span', '', valueText(v))); section.append(list);
      } else section.append(el('div', 'attribute-value', valueText(item.value)));
    }
    root.append(section);
  }
}

function renderMap(root: HTMLElement, graph: Snapshot['map_graph']) {
  const nodes = graph?.nodes || [], edges = graph?.edges || [];
  if (!nodes.length) { root.append(el('p', 'loading', '当前地图暂无节点。')); return; }
  const ids = new Set(nodes.map(n => n.node_id));
  const validEdges = edges.filter(e => ids.has(e.source_node_id) && ids.has(e.target_node_id));
  const neighbors = new Map(nodes.map(n => [n.node_id, [] as string[]]));
  const indegree = new Map(nodes.map(n => [n.node_id, 0]));
  for (const e of validEdges) {
    neighbors.get(e.source_node_id)!.push(e.target_node_id);
    indegree.set(e.target_node_id, indegree.get(e.target_node_id)! + 1);
  }
  // Breadth layers preserve branches and tolerate cycles and disconnected components.
  const depths = new Map<string, number>();
  const roots = nodes.filter(n => indegree.get(n.node_id) === 0).map(n => n.node_id);
  for (const start of [...roots, ...nodes.map(n => n.node_id)]) {
    if (depths.has(start)) continue;
    const offset = depths.size ? Math.max(...depths.values()) + 1 : 0;
    depths.set(start, offset); const queue = [start];
    for (let i = 0; i < queue.length; i++) for (const child of neighbors.get(queue[i]) || []) {
      if (!depths.has(child)) { depths.set(child, depths.get(queue[i])! + 1); queue.push(child); }
    }
  }
  const layers = new Map<number, string[]>();
  for (const n of nodes) { const d = depths.get(n.node_id)!; const layer = layers.get(d) || []; layer.push(n.node_id); layers.set(d, layer); }
  const maxColumns = Math.max(...[...layers.values()].map(l => l.length));
  const width = Math.max(340, maxColumns * 184 + 64), height = layers.size * 105 + 64;
  const positions = new Map<string, { x: number; y: number }>();
  for (const [depth, layer] of layers) layer.forEach((id, i) => positions.set(id, { x: width / 2 + (i - (layer.length - 1) / 2) * 184, y: 42 + depth * 105 }));
  root.append(el('p', 'map-summary', `${nodes.find(n => n.current)?.label || '尚未定位'} · 当前地点`));
  const viewport = el('div', 'topology');
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('aria-label', '地图拓扑图'); svg.setAttribute('role', 'img');
  const scene = document.createElementNS(svg.namespaceURI, 'g'); svg.append(scene);
  for (const edge of validEdges) {
    const a = positions.get(edge.source_node_id)!, b = positions.get(edge.target_node_id)!;
    const path = document.createElementNS(svg.namespaceURI, 'path');
    path.setAttribute('data-edge-id', edge.edge_id);
    const current = nodes.some(n => n.current && (n.node_id === edge.source_node_id || n.node_id === edge.target_node_id));
    path.setAttribute('class', 'topology-edge' + (current ? ' current' : ''));
    const y1 = a.y + 24, y2 = b.y - 24;
    path.setAttribute('d', y2 > y1 ? `M${a.x},${y1} C${a.x},${(y1 + y2) / 2} ${b.x},${(y1 + y2) / 2} ${b.x},${y2}` : `M${a.x + 75},${a.y} C${width - 5},${a.y} ${width - 5},${b.y} ${b.x + 75},${b.y}`);
    scene.append(path);
  }
  for (const node of nodes) {
    const pos = positions.get(node.node_id)!;
    const g = document.createElementNS(svg.namespaceURI, 'g'); g.setAttribute('data-node-id', node.node_id);
    g.setAttribute('class', 'topology-node' + (node.current ? ' current' : '') + (!node.discovered ? ' undiscovered' : ''));
    const rect = document.createElementNS(svg.namespaceURI, 'rect');
    rect.setAttribute('x', String(pos.x - 75)); rect.setAttribute('y', String(pos.y - 24)); rect.setAttribute('width', '150'); rect.setAttribute('height', '48'); rect.setAttribute('rx', '5');
    const label = document.createElementNS(svg.namespaceURI, 'text'); label.setAttribute('x', String(pos.x)); label.setAttribute('y', String(pos.y + 5)); label.setAttribute('text-anchor', 'middle'); label.textContent = (node.current ? '◆ ' : '') + node.label;
    const title = document.createElementNS(svg.namespaceURI, 'title'); title.textContent = node.label + (node.current ? '（当前地点）' : node.discovered ? '（已发现）' : '（未探索）');
    g.append(title, rect, label); scene.append(g);
  }
  let view = { x: 0, y: 0, w: width, h: height };
  const update = () => svg.setAttribute('viewBox', `${view.x} ${view.y} ${view.w} ${view.h}`);
  const zoom = (factor: number) => {
    const nextWidth = Math.max(width / 5, Math.min(width * 3, view.w * factor)); const scale = nextWidth / view.w;
    view = { x: view.x + view.w * (1 - scale) / 2, y: view.y + view.h * (1 - scale) / 2, w: nextWidth, h: view.h * scale }; update();
  };
  update(); viewport.append(svg); root.append(viewport);
  const controls = el('div', 'map-controls');
  for (const [label, fn] of [['放大', () => zoom(.8)], ['缩小', () => zoom(1.25)], ['适应视图', () => { view = { x: 0, y: 0, w: width, h: height }; update(); }]] as const) {
    const button = el('button', 'button', label); button.type = 'button'; button.onclick = fn; controls.append(button);
  }
  root.append(controls, el('p', 'map-hint', `拖动平移，滚轮或按钮缩放 · ${nodes.length} 个地点 / ${validEdges.length} 条路径`));
  svg.addEventListener('wheel', e => { e.preventDefault(); zoom(e.deltaY < 0 ? .9 : 1.1); }, { passive: false });
  let drag: { id: number; x: number; y: number } | null = null;
  svg.addEventListener('pointerdown', e => { drag = { id: e.pointerId, x: e.clientX, y: e.clientY }; svg.setPointerCapture(e.pointerId); });
  svg.addEventListener('pointermove', e => {
    if (!drag || drag.id !== e.pointerId) return;
    const rect = svg.getBoundingClientRect(); const ratio = Math.max(view.w / rect.width, view.h / rect.height);
    view.x -= (e.clientX - drag.x) * ratio; view.y -= (e.clientY - drag.y) * ratio; drag.x = e.clientX; drag.y = e.clientY; update();
  });
  const release = () => { drag = null; }; svg.addEventListener('pointerup', release); svg.addEventListener('pointercancel', release);
}

function cot(text: string, title: string, key: string, streaming: boolean) {
  const root = el('section', 'game-cot'); root.dataset.streaming = String(streaming);
  root.append(el('div', 'game-cot-label', title));
  root.append(el('div', 'game-cot-content', expanded.has(key) ? text : text.slice(0, 200)));
  if (text.length > 200) {
    const toggle = el('button', 'cot-toggle', expanded.has(key) ? '收起' : '展开全部'); toggle.type = 'button';
    toggle.onclick = () => { expanded.has(key) ? expanded.delete(key) : expanded.add(key); messagesKey = ''; renderMessages(state); }; root.append(toggle);
  }
  return root;
}
type Interaction = {
  interaction_id: string;
  kind: string;
  prompt: string;
  config: Record<string, unknown>;
  status: string;
  answer?: unknown;
};
function interactionFrom(value: unknown): Interaction | null {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  const item = value as Record<string, unknown>;
  if (typeof item.interaction_id !== 'string' || typeof item.kind !== 'string') return null;
  return {
    interaction_id: item.interaction_id,
    kind: item.kind,
    prompt: typeof item.prompt === 'string' ? item.prompt : '',
    config: item.config && typeof item.config === 'object' && !Array.isArray(item.config) ? item.config as Record<string, unknown> : {},
    status: typeof item.status === 'string' ? item.status : 'pending',
    answer: item.answer,
  };
}
function renderInteraction(messageId: string, interaction: Interaction, submitting: boolean) {
  const root = el('article', 'message message--interaction');
  root.append(el('div', 'speaker', '待你决定'), el('div', 'interaction-prompt', interaction.prompt));
  const answerKey = `${messageId}:${interaction.interaction_id}`;
  const answered = interaction.status !== 'pending';
  const disabled = answered || submitting || answeringInteractions.has(answerKey) || !messageId;
  const answer = (value: unknown) => {
    if (disabled || answeringInteractions.has(answerKey)) return;
    answeringInteractions.add(answerKey);
    messagesKey = '';
    renderMessages(state);
    void world.actions.answerInteraction(messageId, interaction.interaction_id, value)
      .catch(showError)
      .finally(() => { answeringInteractions.delete(answerKey); messagesKey = ''; renderMessages(state); });
  };
  if (answered) {
    const value = interaction.answer;
    let label = valueText(value);
    if (interaction.kind === 'choice' && Array.isArray(interaction.config.options)) {
      const option = interaction.config.options.find(item => item && typeof item === 'object' && (item as Record<string, unknown>).id === value) as Record<string, unknown> | undefined;
      if (typeof option?.label === 'string') label = option.label;
    } else if (interaction.kind === 'confirm') {
      label = value === true ? valueText(interaction.config.confirm_label || '确认') : valueText(interaction.config.cancel_label || '取消');
    }
    root.append(el('div', 'interaction-answer', `已选择：${label}`));
    return root;
  }
  const controls = el('div', 'interaction-controls');
  if (interaction.kind === 'choice' && Array.isArray(interaction.config.options)) {
    for (const option of interaction.config.options) {
      if (!option || typeof option !== 'object') continue;
      const item = option as Record<string, unknown>;
      if (typeof item.id !== 'string' || typeof item.label !== 'string') continue;
      const button = el('button', 'interaction-option', item.label);
      button.type = 'button'; button.disabled = disabled; button.onclick = () => answer(item.id); controls.append(button);
    }
  } else if (interaction.kind === 'confirm') {
    for (const [value, label] of [[true, interaction.config.confirm_label || '确认'], [false, interaction.config.cancel_label || '取消']] as const) {
      const button = el('button', 'interaction-option', valueText(label));
      button.type = 'button'; button.disabled = disabled; button.onclick = () => answer(value); controls.append(button);
    }
  } else if (interaction.kind === 'slider') {
    const min = Number(interaction.config.min), max = Number(interaction.config.max);
    if (Number.isFinite(min) && Number.isFinite(max) && min < max) {
      const step = Number(interaction.config.step) > 0 ? Number(interaction.config.step) : 1;
      const initial = Math.max(min, Math.min(max, Number(interaction.config.default ?? min)));
      const range = el('input', 'interaction-slider') as HTMLInputElement;
      range.type = 'range'; range.min = String(min); range.max = String(max); range.step = String(step); range.value = String(initial); range.disabled = disabled;
      const value = el('output', 'interaction-slider-value', range.value);
      range.oninput = () => { value.value = range.value; value.textContent = range.value; };
      const submit = el('button', 'interaction-option', '确认');
      submit.type = 'button'; submit.disabled = disabled; submit.onclick = () => answer(Number(range.value));
      controls.append(range, value, submit);
    }
  }
  if (controls.childElementCount) root.append(controls);
  return root;
}
function renderMessages(s: Snapshot) {
  const signature = JSON.stringify([s.messages, s.ui_state?.submitting, s.editing]);
  if (signature === messagesKey) return; messagesKey = signature;
  const follow = forceFollow || messages.scrollHeight - messages.scrollTop - messages.clientHeight < 70;
  const oldTop = messages.scrollTop; messages.replaceChildren();
  for (const [index, m] of (s.messages || []).entries()) {
    const meta = m.metadata || {}, key = m.message_id || `${m.role}:${index}`;
    if (meta.message_kind === 'world_interaction') {
      const interaction = interactionFrom(meta.interaction);
      if (interaction) messages.append(renderInteraction(m.message_id || '', interaction, !!s.ui_state?.submitting));
      continue;
    }
    if (['character_creation', 'switch_proposal'].includes(String(meta.message_kind))) continue;
    const isDirector = meta.action_type === 'director_trace';
    const streaming = meta.streaming === true;
    if (isDirector) {
      const text = valueText(meta.reasoning || meta.trace_text || messageText(m));
      if (text) messages.append(cot(text, '世界主控思维链', key, streaming)); continue;
    }
    const isPlayer = ['player', 'user'].includes(m.role), isSystem = ['system', 'narration'].includes(m.role);
    const text = messageText(m);
    if (m.role === 'narration' || ['event', 'narration_event'].includes(String(meta.message_kind))) {
      if (text) messages.append(el('article', 'event', text));
      continue;
    }
    if (!text && !meta.reasoning && !meta.tool_activity) continue;
    const row = el('article', 'message message--' + (isPlayer ? 'player' : isSystem ? 'system' : 'agent'));
    row.append(el('div', 'speaker', m.speaker || (isPlayer ? s.player?.name || '玩家' : isSystem ? '旁白' : '角色')));
    if (meta.reasoning) row.append(cot(valueText(meta.reasoning), '角色思维链', key, streaming));
    const activity = meta.tool_activity as { status?: string; tools?: { name: string }[] } | undefined;
    if (activity) row.append(el('div', 'tool' + (activity.status === 'calling' ? ' streaming' : ''), (activity.status === 'calling' ? '正在调用：' : '已调用：') + (activity.tools || []).map(t => t.name).join('、')));
    row.append(el('div', 'message-content', text));
    if (!isSystem && !m.pending) {
      const actions = el('div', 'message-actions');
      const button = (label: string, fn: () => Promise<unknown> | void) => {
        const b = el('button', '', label); b.type = 'button'; b.disabled = !!s.ui_state?.submitting;
        b.onclick = () => { const result = fn(); if (result) void result.catch(showError); }; actions.append(b);
      };
      if (isPlayer) {
        const turn = Number(meta.turn_index);
        if (Number.isInteger(turn) && turn > 0) {
          button('编辑', async () => { await world.actions.editTurn(text, turn); input.value = text; draftDirty = true; input.focus(); });
          button('重发', () => submit({ content: text, mode: 'resend', turnIndex: turn }));
        }
      } else { button('复制', () => world.actions.copyText(text)); button('分支', () => world.actions.branch()); }
      row.append(actions);
    }
    messages.append(row);
    if (meta.narration) messages.append(el('article', 'message message--system', valueText(meta.narration)));
  }
  if (!(s.messages || []).length) messages.append(el('p', 'empty', '故事将从这里开始。'));
  if (s.ui_state?.submitting) messages.append(el('div', 'thinking-indicator', '正在思考与行动…'));
  messages.scrollTop = follow ? messages.scrollHeight : oldTop; forceFollow = false;
}

function render(s: Snapshot) {
  state = s;
  setText('world-name', s.world?.name || '凡人修仙');
  const timeLabel = valueText(s.attributes?.mortal_time) || s.session?.time_label || '';
  setText('location', [s.session?.location, timeLabel].filter(Boolean).join(' · '));
  setText('ledger-location', s.session?.location || '未定');
  setText('player-name', s.player?.name || s.session?.player_character_name || '陆谨');
  setText('time', timeLabel);
  const roster = $('characters')!; roster.replaceChildren();
  for (const name of s.visible_characters || []) roster.append(el('span', 'pill', name));
  const focusImage = $('focus-image');
  if (focusImage) {
    focusImage.replaceChildren();
    if (s.scene_focus?.portrait_path) { const img = el('img'); img.src = s.scene_focus.portrait_path; img.alt = s.scene_focus.speaker; focusImage.append(img); }
    else focusImage.textContent = s.scene_focus?.speaker || '当前场景';
  }
  setText('focus-line', s.scene_focus?.content || '山风未定，前路尚待落笔。');
  renderTabs(s); renderLedger(s); renderMessages(s);
  if (s.editing?.turnIndex !== editingTurn) {
    editingTurn = s.editing?.turnIndex;
    if (s.editing) { input.value = s.draft_input?.value || s.editing.originalContent; draftDirty = true; }
  }
  // Own draft locally while typing or awaiting a result; never overwrite on blur/snapshot.
  if (!draftDirty && !sending && document.activeElement !== input) input.value = s.draft_input?.value || '';
  const cancel = $('cancel-edit'); if (cancel) cancel.hidden = !s.editing;
  const voice = $('voice'); if (voice) { voice.setAttribute('aria-label', s.draft_input?.is_recording ? '结束录音' : '开始录音'); voice.classList.toggle('recording', !!s.draft_input?.is_recording); }
  const attachments = $('attachments');
  if (attachments) {
    attachments.replaceChildren();
    for (const [kind, files] of [['image', s.draft_input?.images], ['audio', s.draft_input?.audios]] as const) for (const [i, file] of (files || []).entries()) {
      const remove = el('button', 'attachment', `${file.name} ×`); remove.type = 'button';
      remove.onclick = () => run(() => kind === 'image' ? world.actions.removeImage(i) : world.actions.removeAudio(i)); attachments.append(remove);
    }
  }
  if (s.draft_input?.microphone_error) localError = s.draft_input.microphone_error;
  updateStatus();
}

const drawer = $('drawer'), handle = $('handle');
if (drawer && handle) {
  const toggle = (open: boolean) => { drawer.classList.toggle('open', open); handle.setAttribute('aria-expanded', String(open)); };
  handle.onclick = () => toggle(!drawer.classList.contains('open'));
  $('close')!.onclick = () => toggle(false);
  drawer.onclick = e => { if (e.target === drawer) toggle(false); };
  document.addEventListener('keydown', e => { if (e.key === 'Escape') toggle(false); });
}

const ledgerToggle = $<HTMLButtonElement>('ledger-toggle'), ledgerPanel = $('ledger');
if (ledgerToggle && ledgerPanel) {
  const collapse = (collapsed: boolean) => {
    document.body.classList.toggle('ledger-collapsed', collapsed);
    ledgerToggle.setAttribute('aria-pressed', String(!collapsed));
    ledgerToggle.textContent = collapsed ? '行囊 ›' : '行囊';
  };
  collapse(false);
  ledgerToggle.onclick = () => collapse(!document.body.classList.contains('ledger-collapsed'));
}

world.subscribe(render);
