# 健康生活世界包

单智能体健康管理世界：与「健康小助手」对话，使用「对话 / 记录 / 计划 / 我的」四个页签。桌面与 Android 各有一份完整 HTML 界面，移动端不是桌面布局的缩小版。

## 功能

- **对话**：饮食、训练、睡眠；小助手通过 `session_attribute_updates` 维护今日摄入/消耗与身体档案。支持图片、语音和主控交互卡片。
- **记录**：今日能量环、摄入/消耗柱状图、按天回看；“同步今日”把当前属性写入 `health.energy_days`，历史统计由包内 `logic.js` 计算。
- **计划**：今日重点、今日行动清单；勾选完成会作为一条普通消息发给小助手，由小助手更新清单。
- **我的**：只读身高体重、BMI/BMR、目标与进度；更新仍在对话中完成。

## 构建

`ui.ts` 是共享交互源码，`ui.desktop.css` / `ui.mobile.css` 是两端样式源：

```powershell
cd E:\code\rustweb
node scripts/build-assistant-world-ui.mjs healthy-life
python scripts/pack_world_zip.py healthy-life
```

产物：`output/healthy-life-world.zip`。

## 数据

- 今日实时数字：`health_*` session 属性（模型写回）。
- 历史统计：世界存储集合 `health.energy_days`，通过 `logic.js` 的 `health.syncStats` / `health.loadStats` / `health.selectDay` 读写。
- UI 页签是本地状态，不再依赖宿主的侧栏组件或旧的 `set_state` 界面指令。
- 柱状图使用真实记录：近 7 天或本月每一天；没有记录时明确显示空态。

## 依赖

- 世界包格式 version 10
- UI runtime version 3
- `supports_world_records` + `supports_world_storage`
- `sandbox-js-v1` logic（`timeout_ms` 2000）
- 无额外平台能力、无外部网络请求
