// Authoring source. scripts/build-assistant-world-ui.mjs embeds the compiled JS in both HTML entries.
type Snapshot = {
  world?: { name?: string };
  session?: { time_label?: string | null; location?: string | null };
  player?: { name?: string };
  attributes?: Record<string, unknown>;
  messages?: Message[];
  draft_input?: {
    value?: string;
    images?: Attachment[];
    audios?: Attachment[];
    is_recording?: boolean;
    microphone_error?: string | null;
  };
  editing?: { turnIndex: number; originalContent: string } | null;
  ui_state?: { submitting?: boolean; loading?: boolean; page_error?: string | null };
  errors?: { action_error?: string | null; page_error?: string | null };
};
type ContentPart = { type: string; text?: string; image_url?: { url?: string }; input_audio?: { data?: string; format?: string } };
type Message = {
  message_id?: string;
  role: string;
  content: string | ContentPart[];
  speaker?: string | null;
  metadata?: Record<string, unknown> | null;
  pending?: boolean;
};
type Attachment = { id?: string; name?: string; size?: number; type?: string; preview_url?: string };
type Interaction = {
  interaction_id: string;
  kind: string;
  prompt: string;
  config: Record<string, unknown>;
  status: string;
  answer?: unknown;
};
type Stats = {
  today?: Day;
  week_bars?: Bar[];
  month_bars?: Bar[];
  day_list?: DayRow[];
  selected?: Day;
  week_avg?: { intake?: number; burn?: number; net?: number };
  month_avg?: { intake?: number; burn?: number; net?: number };
  recorded_days?: number;
};
type Day = { date?: string; intake?: number; burn?: number; net?: number; bmr?: number; steps?: number };
type DayRow = { date?: string; label?: string; intake?: number; burn?: number; net?: number; steps?: number; is_today?: boolean };
type Bar = { date?: string; label?: string; intake?: number; burn?: number; net?: number; height?: string; h_in?: string; h_burn?: string; selected?: boolean };
type Actions = {
  submitMessage(options: { content?: string; mode?: 'submit' | 'edit' | 'resend'; turnIndex?: number }): Promise<unknown>;
  clearError(): Promise<unknown>;
  copyText(text: string): Promise<unknown>;
  branch(): Promise<unknown>;
  editTurn(content: string, turnIndex: number): Promise<unknown>;
  cancelEdit(): Promise<unknown>;
  pickImage(): Promise<unknown>;
  startRecording(): Promise<unknown>;
  stopRecording(send?: boolean): Promise<unknown>;
  removeImage(index: number): Promise<unknown>;
  removeAudio(index: number): Promise<unknown>;
  answerInteraction(messageId: string, interactionId: string, answer: unknown): Promise<unknown>;
  navigate(target: string): Promise<unknown>;
};
type WorldSdk = { getState(): Snapshot; subscribe(listener: (state: Snapshot) => void): () => void; actions: Actions; logic: { run(handler: string, input?: unknown): Promise<unknown> } };

const world = (window as unknown as { world: WorldSdk }).world;
const $ = <T extends HTMLElement = HTMLElement>(id: string) => document.getElementById(id) as T | null;
const qs = <T extends HTMLElement = HTMLElement>(selector: string) => document.querySelector(selector) as T | null;
const qsa = <T extends HTMLElement = HTMLElement>(selector: string) => Array.from(document.querySelectorAll(selector)) as T[];
const el = <K extends keyof HTMLElementTagNameMap>(tag: K, className = '', text = '') => {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text) node.textContent = text;
  return node;
};
const ns = 'http://www.w3.org/2000/svg';
const svgEl = (tag: string) => document.createElementNS(ns, tag);
const valueText = (value: unknown): string => typeof value === 'string' ? value : value == null ? '' : JSON.stringify(value);
const num = (value: unknown) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
};
const kcal = (value: unknown) => `${Math.round(num(value))} kcal`;
const input = $<HTMLTextAreaElement>('input')!;
const messages = $('messages')!;
const statusNode = $('status')!;
const send = $<HTMLButtonElement>('send')!;
let state: Snapshot = {};
let tab = 'chat';
let stats: Stats | null = null;
let chartMode: 'week' | 'month' = 'week';
let statsLoading = false;
let sending = false;
let localError = '';
let draftDirty = false;
let forceFollow = false;
let messagesKey = '';
let editingTurn: number | undefined;
const expanded = new Set<string>();
const answering = new Set<string>();
const selectedItems = new Set<string>();

function errorText(error: unknown) {
  return error instanceof Error ? error.message : String(error);
}
function showError(error: unknown) {
  localError = errorText(error);
  updateStatus();
  const banner = $('page-error');
  if (banner) {
    banner.textContent = localError;
    banner.hidden = !localError;
  }
}
function run(work: () => Promise<unknown>) {
  void work().catch(showError);
}
function setText(id: string, text: string) {
  const node = $(id);
  if (node) node.textContent = text;
}
function clearPageError() {
  localError = '';
  const banner = $('page-error');
  if (banner) banner.hidden = true;
  updateStatus();
}
function attribute(key: string) {
  return state.attributes?.[key];
}
function listAttribute(key: string): string[] {
  const value = attribute(key);
  if (Array.isArray(value)) return value.map((item) => valueText(item)).filter(Boolean);
  if (typeof value === 'string' && value) {
    try {
      const parsed = JSON.parse(value);
      if (Array.isArray(parsed)) return parsed.map((item) => valueText(item)).filter(Boolean);
    } catch {
      return value.split('\n').map((item) => item.trim()).filter(Boolean);
    }
  }
  return [];
}

function updateStatus() {
  const error = localError || state.errors?.action_error || state.errors?.page_error || state.ui_state?.page_error;
  statusNode.textContent = error || (sending || state.ui_state?.submitting ? '小助手正在整理…' : '');
  statusNode.setAttribute('role', error ? 'alert' : 'status');
  statusNode.classList.toggle('has-error', Boolean(error));
  send.disabled = sending || !!state.ui_state?.submitting;
  send.textContent = sending || state.ui_state?.submitting ? '发送中' : state.editing ? '保存并重发' : '发送';
}
function messageText(message: Message) {
  if (typeof message.content === 'string') return message.content;
  return message.content.filter((part) => part.type === 'text').map((part) => part.text || '').join('\n');
}
function messageParts(message: Message) {
  return typeof message.content === 'string' ? [] : message.content;
}
async function submit(options?: { content?: string; mode?: 'submit' | 'edit' | 'resend'; turnIndex?: number }): Promise<boolean> {
  if (sending || state.ui_state?.submitting) {
    showError('上一条消息仍在处理，请稍候。');
    return false;
  }
  const content = options?.content ?? input.value.trim();
  if (!content && !state.draft_input?.images?.length && !state.draft_input?.audios?.length) {
    showError('先写点什么，或添加一张图片、一段语音。');
    return false;
  }
  sending = true;
  localError = '';
  forceFollow = true;
  updateStatus();
  try {
    await world.actions.clearError();
    await world.actions.submitMessage({
      content,
      mode: options?.mode ?? (state.editing ? 'edit' : 'submit'),
      turnIndex: options?.turnIndex ?? state.editing?.turnIndex,
    });
    if (!options && input.value.trim() === content) {
      input.value = '';
      draftDirty = false;
    }
    return true;
  } catch (error) {
    showError(error);
    return false;
  } finally {
    sending = false;
    updateStatus();
  }
}
send.type = 'button';
send.onclick = () => void submit();
input.oninput = () => { draftDirty = true; };
input.onkeydown = (event) => {
  if (event.key === 'Enter' && !event.shiftKey && !event.isComposing && document.body.dataset.platform !== 'mobile') {
    event.preventDefault();
    void submit();
  }
};
window.addEventListener('world-error', (event) => showError((event as CustomEvent<{ message: string }>).detail.message));
$('attach')?.addEventListener('click', () => run(() => world.actions.pickImage()));
$('voice')?.addEventListener('click', () => run(() => state.draft_input?.is_recording ? world.actions.stopRecording() : world.actions.startRecording()));
$('cancel-edit')?.addEventListener('click', () => run(() => world.actions.cancelEdit()));

function cot(text: string, title: string, key: string, streaming: boolean) {
  const root = el('section', 'game-cot');
  root.dataset.streaming = String(streaming);
  root.append(el('div', 'game-cot-label', title));
  root.append(el('div', 'game-cot-content', expanded.has(key) ? text : text.slice(0, 200)));
  if (text.length > 200) {
    const toggle = el('button', 'cot-toggle', expanded.has(key) ? '收起' : '展开全部');
    toggle.type = 'button';
    toggle.onclick = () => {
      if (expanded.has(key)) expanded.delete(key);
      else expanded.add(key);
      messagesKey = '';
      renderMessages(state);
    };
    root.append(toggle);
  }
  return root;
}
function interactionFrom(value: unknown): Interaction | null {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  const item = value as Record<string, unknown>;
  if (typeof item.interaction_id !== 'string' || typeof item.kind !== 'string') return null;
  return {
    interaction_id: item.interaction_id,
    kind: item.kind,
    prompt: typeof item.prompt === 'string' ? item.prompt : '',
    config: item.config && typeof item.config === 'object' && !Array.isArray(item.config) ? item.config as Record<string, unknown> : {},
    status: typeof item.status === 'string' ? item.status : 'pending',
    answer: item.answer,
  };
}
function answeredLabel(interaction: Interaction) {
  const value = interaction.answer;
  if (interaction.kind === 'choice' && Array.isArray(interaction.config.options)) {
    const option = interaction.config.options.find((item) => item && typeof item === 'object' && (item as Record<string, unknown>).id === value) as Record<string, unknown> | undefined;
    if (typeof option?.label === 'string') return option.label;
  }
  if (interaction.kind === 'multi_choice' && Array.isArray(value)) {
    const options = Array.isArray(interaction.config.options) ? interaction.config.options : [];
    return value.map((item) => {
      const option = options.find((candidate) => candidate && typeof candidate === 'object' && (candidate as Record<string, unknown>).id === item) as Record<string, unknown> | undefined;
      return typeof option?.label === 'string' ? option.label : valueText(item);
    }).join('、');
  }
  if (interaction.kind === 'confirm') return value === true ? valueText(interaction.config.confirm_label || '确认') : valueText(interaction.config.cancel_label || '取消');
  return valueText(value);
}
function interactionOptions(interaction: Interaction) {
  return Array.isArray(interaction.config.options)
    ? interaction.config.options.filter((item): item is Record<string, unknown> => !!item && typeof item === 'object' && typeof (item as Record<string, unknown>).id === 'string')
    : [];
}
function renderInteraction(messageId: string, interaction: Interaction, submitting: boolean) {
  const root = el('article', 'message message--interaction');
  root.append(el('div', 'speaker', '待你回答'), el('div', 'interaction-prompt', interaction.prompt));
  const answerKey = `${messageId}:${interaction.interaction_id}`;
  const answered = interaction.status !== 'pending';
  const busy = answering.has(answerKey);
  const disabled = answered || submitting || busy || !messageId;
  const answer = (value: unknown) => {
    if (disabled) return;
    answering.add(answerKey);
    messagesKey = '';
    renderMessages(state);
    void world.actions.answerInteraction(messageId, interaction.interaction_id, value)
      .catch(showError)
      .finally(() => {
        answering.delete(answerKey);
        messagesKey = '';
        renderMessages(state);
      });
  };
  if (answered) {
    root.append(el('div', 'interaction-answer', `已回答：${answeredLabel(interaction)}`));
    return root;
  }
  const controls = el('div', 'interaction-controls');
  if (interaction.kind === 'choice') {
    for (const option of interactionOptions(interaction)) {
      const button = el('button', 'interaction-option', valueText(option.label || option.id));
      button.type = 'button';
      button.disabled = disabled;
      button.onclick = () => answer(option.id);
      controls.append(button);
    }
  } else if (interaction.kind === 'multi_choice') {
    const chosen = new Set<string>();
    const submitChoice = el('button', 'interaction-option is-primary', '提交选择');
    submitChoice.type = 'button';
    submitChoice.disabled = disabled;
    for (const option of interactionOptions(interaction)) {
      const button = el('button', 'interaction-option', valueText(option.label || option.id));
      button.type = 'button';
      button.disabled = disabled;
      button.setAttribute('aria-pressed', 'false');
      button.onclick = () => {
        const id = String(option.id);
        if (chosen.has(id)) chosen.delete(id);
        else chosen.add(id);
        button.classList.toggle('is-chosen', chosen.has(id));
        button.setAttribute('aria-pressed', String(chosen.has(id)));
        submitChoice.disabled = disabled || chosen.size === 0;
      };
      controls.append(button);
    }
    submitChoice.onclick = () => answer(Array.from(chosen));
    controls.append(submitChoice);
  } else if (interaction.kind === 'confirm') {
    for (const [value, label] of [[true, interaction.config.confirm_label || '确认'], [false, interaction.config.cancel_label || '取消']] as const) {
      const button = el('button', 'interaction-option', valueText(label));
      button.type = 'button';
      button.disabled = disabled;
      button.onclick = () => answer(value);
      controls.append(button);
    }
  } else if (interaction.kind === 'slider') {
    const min = num(interaction.config.min);
    const max = num(interaction.config.max);
    if (max > min) {
      const step = num(interaction.config.step) > 0 ? num(interaction.config.step) : 1;
      const initial = Math.max(min, Math.min(max, num(interaction.config.default ?? min)));
      const range = el('input', 'interaction-slider') as HTMLInputElement;
      range.type = 'range';
      range.min = String(min);
      range.max = String(max);
      range.step = String(step);
      range.value = String(initial);
      range.disabled = disabled;
      const output = el('output', 'interaction-slider-value', range.value);
      range.oninput = () => { output.value = range.value; output.textContent = range.value; };
      const submitRange = el('button', 'interaction-option', '确认');
      submitRange.type = 'button';
      submitRange.disabled = disabled;
      submitRange.onclick = () => answer(Number(range.value));
      controls.append(range, output, submitRange);
    }
  } else if (interaction.kind === 'form') {
    const fields = Array.isArray(interaction.config.fields) ? interaction.config.fields : [];
    const values: Record<string, unknown> = {};
    for (const raw of fields) {
      if (!raw || typeof raw !== 'object') continue;
      const field = raw as Record<string, unknown>;
      const id = String(field.id || '');
      if (!id) continue;
      const label = el('label', 'form-field');
      label.append(el('span', '', valueText(field.label || id)));
      const kind = String(field.input || 'text');
      if (kind === 'textarea') {
        const area = el('textarea') as HTMLTextAreaElement;
        area.rows = 3;
        area.placeholder = valueText(field.placeholder || '');
        area.oninput = () => { values[id] = area.value; };
        label.append(area);
      } else if (kind === 'select' || kind === 'radio') {
        const select = el('select') as HTMLSelectElement;
        const options = Array.isArray(field.options) ? field.options : [];
        for (const option of options) {
          const item = typeof option === 'object' && option ? option as Record<string, unknown> : { id: String(option), label: String(option) };
          const node = el('option', '', valueText(item.label || item.id));
          node.value = String(item.id);
          select.append(node);
        }
        select.onchange = () => { values[id] = select.value; };
        values[id] = select.value;
        label.append(select);
      } else if (kind === 'checkbox') {
        const box = el('input') as HTMLInputElement;
        box.type = 'checkbox';
        box.onchange = () => { values[id] = box.checked; };
        values[id] = false;
        label.append(box);
      } else {
        const fieldInput = el('input') as HTMLInputElement;
        fieldInput.type = kind === 'number' ? 'number' : 'text';
        fieldInput.placeholder = valueText(field.placeholder || '');
        fieldInput.oninput = () => { values[id] = kind === 'number' ? Number(fieldInput.value) : fieldInput.value; };
        values[id] = kind === 'number' ? 0 : '';
        label.append(fieldInput);
      }
      controls.append(label);
    }
    const submitForm = el('button', 'interaction-option', '提交');
    submitForm.type = 'button';
    submitForm.disabled = disabled;
    submitForm.onclick = () => answer(values);
    controls.append(submitForm);
  }
  if (controls.childElementCount) root.append(controls);
  return root;
}
function renderMessages(snapshot: Snapshot) {
  const signature = JSON.stringify([snapshot.messages, snapshot.ui_state?.submitting, snapshot.editing]);
  if (signature === messagesKey) return;
  messagesKey = signature;
  const follow = forceFollow || messages.scrollHeight - messages.scrollTop - messages.clientHeight < 80;
  const oldTop = messages.scrollTop;
  messages.replaceChildren();
  for (const [index, message] of (snapshot.messages || []).entries()) {
    const meta = message.metadata || {};
    const key = message.message_id || `${message.role}:${index}`;
    if (meta.message_kind === 'world_interaction') {
      const interaction = interactionFrom(meta.interaction);
      if (interaction) messages.append(renderInteraction(message.message_id || '', interaction, !!snapshot.ui_state?.submitting));
      continue;
    }
    if (['character_creation', 'switch_proposal'].includes(String(meta.message_kind))) continue;
    const isDirector = meta.action_type === 'director_trace';
    const streaming = meta.streaming === true;
    if (isDirector) {
      const text = valueText(meta.reasoning || meta.trace_text || messageText(message));
      if (text) messages.append(cot(text, '小助手思考', key, streaming));
      continue;
    }
    const isPlayer = ['player', 'user'].includes(message.role);
    const isSystem = ['system', 'narration'].includes(message.role);
    const text = messageText(message);
    if (message.role === 'narration' || ['event', 'narration_event'].includes(String(meta.message_kind))) {
      if (text) messages.append(el('article', 'event', text));
      continue;
    }
    if (!text && !meta.reasoning && !meta.tool_activity && !messageParts(message).length) continue;
    const row = el('article', `message message--${isPlayer ? 'player' : isSystem ? 'system' : 'agent'}`);
    row.append(el('div', 'speaker', message.speaker || (isPlayer ? snapshot.player?.name || '我' : isSystem ? '提示' : '健康小助手')));
    if (meta.reasoning) row.append(cot(valueText(meta.reasoning), '小助手思考', key, streaming));
    const activity = meta.tool_activity as { status?: string; tools?: { name: string }[] } | undefined;
    if (activity) row.append(el('div', 'tool' + (activity.status === 'calling' ? ' streaming' : ''), (activity.status === 'calling' ? '正在调用：' : '已调用：') + (activity.tools || []).map((tool) => tool.name).join('、')));
    if (text) row.append(el('div', 'message-content', text));
    for (const part of messageParts(message)) {
      if (part.type === 'image_url' && part.image_url?.url) {
        const image = el('img', 'message-image') as HTMLImageElement;
        image.src = part.image_url.url;
        image.alt = '图片附件';
        row.append(image);
      } else if (part.type === 'input_audio' && part.input_audio?.data) {
        const audio = el('audio', 'message-audio') as HTMLAudioElement;
        audio.controls = true;
        audio.src = `data:audio/${part.input_audio.format || 'wav'};base64,${part.input_audio.data}`;
        row.append(audio);
      }
    }
    if (!isSystem && !message.pending) {
      const actions = el('div', 'message-actions');
      const button = (label: string, work: () => Promise<unknown> | void) => {
        const node = el('button', '', label);
        node.type = 'button';
        node.disabled = !!snapshot.ui_state?.submitting;
        node.onclick = () => {
          const result = work();
          if (result) void result.catch(showError);
        };
        actions.append(node);
      };
      if (isPlayer) {
        const turn = Number(meta.turn_index);
        if (Number.isInteger(turn) && turn > 0) {
          button('编辑', async () => { await world.actions.editTurn(text, turn); input.value = text; draftDirty = true; input.focus(); });
          button('重发', () => submit({ content: text, mode: 'resend', turnIndex: turn }));
        }
      } else {
        button('复制', () => world.actions.copyText(text));
        button('分支', () => world.actions.branch());
      }
      if (actions.childElementCount) row.append(actions);
    }
    messages.append(row);
    if (meta.narration) messages.append(el('article', 'message message--system', valueText(meta.narration)));
  }
  if (!(snapshot.messages || []).length) messages.append(el('p', 'empty', '先告诉小助手身高、体重和今天的状态，记录会从对话开始。'));
  if (snapshot.ui_state?.submitting) messages.append(el('div', 'thinking-indicator', '小助手正在整理今日数据…'));
  messages.scrollTop = follow ? messages.scrollHeight : oldTop;
  forceFollow = false;
}

function switchTab(next: string) {
  tab = next;
  for (const panel of qsa<HTMLElement>('[data-tab-panel]')) panel.hidden = panel.dataset.tabPanel !== next;
  for (const button of qsa<HTMLElement>('[data-tab]')) {
    const active = button.dataset.tab === next;
    button.classList.toggle('is-active', active);
    button.setAttribute('aria-current', active ? 'page' : 'false');
  }
  if (next === 'records' && !stats && !statsLoading) loadStats();
  if (next === 'profile') renderProfile(state);
  if (next === 'plan') renderPlan(state);
}
function healthInput(selected?: string) {
  return {
    height: num(attribute('health_height_cm')),
    weight: num(attribute('health_weight_kg')),
    age: num(attribute('health_age')),
    gender: valueText(attribute('health_gender')),
    bmi: num(attribute('health_bmi')),
    bmr: num(attribute('health_bmr')),
    intake: num(attribute('health_intake_kcal')),
    burn: num(attribute('health_burn_kcal')),
    net: num(attribute('health_energy_net')),
    steps: num(attribute('health_steps')),
    selected_date: selected,
  };
}
async function loadStats(selected?: string) {
  statsLoading = true;
  renderRecords();
  try {
    const result = await world.logic.run('health.loadStats', healthInput(selected));
    stats = (result && typeof result === 'object' ? result : null) as Stats | null;
    clearPageError();
  } catch (error) {
    showError(error);
  } finally {
    statsLoading = false;
    renderRecords();
  }
}
async function syncStats() {
  if (statsLoading) return;
  statsLoading = true;
  renderRecords();
  try {
    const result = await world.logic.run('health.syncStats', healthInput());
    stats = (result && typeof result === 'object' ? result : null) as Stats | null;
    clearPageError();
    toast('今日数据已同步到记录');
  } catch (error) {
    showError(error);
  } finally {
    statsLoading = false;
    renderRecords();
  }
}
async function selectDay(date: string) {
  if (!date || statsLoading) return;
  statsLoading = true;
  renderRecords();
  try {
    const result = await world.logic.run('health.selectDay', { ...healthInput(date), date });
    stats = (result && typeof result === 'object' ? result : null) as Stats | null;
    clearPageError();
  } catch (error) {
    showError(error);
  } finally {
    statsLoading = false;
    renderRecords();
  }
}
function renderRing(day: Day | undefined) {
  const root = $('energy-ring');
  if (!root) return;
  root.replaceChildren();
  const intake = num(day?.intake);
  const burn = num(day?.burn);
  const max = Math.max(intake, burn, 1);
  const size = 184;
  const center = size / 2;
  const svg = svgEl('svg') as SVGSVGElement;
  svg.setAttribute('viewBox', `0 0 ${size} ${size}`);
  svg.setAttribute('role', 'img');
  svg.setAttribute('aria-label', `今日摄入 ${kcal(intake)}，消耗 ${kcal(burn)}`);
  const track = svgEl('circle');
  track.setAttribute('cx', String(center));
  track.setAttribute('cy', String(center));
  track.setAttribute('r', '78');
  track.setAttribute('class', 'ring-track');
  svg.append(track);
  const rings: Array<[string, number, number]> = [['ring-burn', 68, burn / max], ['ring-intake', 54, intake / max]];
  for (const [className, radius, ratio] of rings) {
    const circle = svgEl('circle');
    const circumference = 2 * Math.PI * radius;
    circle.setAttribute('cx', String(center));
    circle.setAttribute('cy', String(center));
    circle.setAttribute('r', String(radius));
    circle.setAttribute('class', className);
    circle.setAttribute('stroke-dasharray', `${circumference * Math.max(0.01, ratio)} ${circumference}`);
    circle.setAttribute('transform', `rotate(-90 ${center} ${center})`);
    svg.append(circle);
  }
  root.append(svg);
  const centerBox = el('div', 'ring-center');
  centerBox.append(el('small', '', '能量净平衡'));
  const net = intake - burn;
  centerBox.append(el('strong', net < 0 ? 'is-negative' : '', `${net > 0 ? '+' : ''}${Math.round(net)}`));
  centerBox.append(el('span', '', 'kcal'));
  root.append(centerBox);
  setText('ring-intake-value', kcal(intake));
  setText('ring-burn-value', kcal(burn));
  setText('ring-date', day?.date ? `${day.date} 的记录` : '今天还没有记录');
}
function renderChart(bars: Bar[] | undefined, average: { intake?: number; burn?: number; net?: number } | undefined) {
  const chart = $('energy-chart');
  if (!chart) return;
  chart.replaceChildren();
  const list = bars || [];
  const hasData = list.some((bar) => num(bar.intake) > 0 || num(bar.burn) > 0);
  const empty = $('chart-empty');
  if (empty) empty.hidden = hasData;
  const max = Math.max(1, ...list.map((bar) => Math.max(num(bar.intake), num(bar.burn))));
  for (const bar of list) {
    const button = el('button', `chart-bar${bar.selected ? ' is-selected' : ''}`);
    button.type = 'button';
    button.setAttribute('aria-label', `${bar.date || bar.label} 摄入 ${kcal(bar.intake)}，消耗 ${kcal(bar.burn)}`);
    const columns = el('span', 'chart-columns');
    const intake = el('i', 'chart-intake');
    intake.style.height = `${Math.max(2, num(bar.intake) / max * 100)}%`;
    const burn = el('i', 'chart-burn');
    burn.style.height = `${Math.max(2, num(bar.burn) / max * 100)}%`;
    columns.append(intake, burn);
    button.append(columns, el('span', 'chart-label', bar.label || (bar.date || '').slice(8) || ''));
    if (bar.date) button.onclick = () => void selectDay(String(bar.date));
    chart.append(button);
  }
  setText('avg-intake', kcal(average?.intake));
  setText('avg-burn', kcal(average?.burn));
  setText('avg-net', `${num(average?.net) > 0 ? '+' : ''}${Math.round(num(average?.net))} kcal`);
  setText('recorded-days', `${stats?.recorded_days || 0} 天有记录`);
}
function renderDayList(rows: DayRow[] | undefined) {
  const root = $('day-list');
  if (!root) return;
  root.replaceChildren();
  const list = rows || [];
  const empty = $('day-list-empty');
  if (empty) empty.hidden = list.length > 0;
  for (const row of list) {
    const button = el('button', `day-row${row.date === stats?.selected?.date ? ' is-selected' : ''}`);
    button.type = 'button';
    const date = el('span', 'day-date');
    date.append(el('strong', '', row.is_today ? '今天' : (row.label || row.date || '').slice(5)));
    date.append(el('small', '', row.date || ''));
    const values = el('span', 'day-values');
    values.append(el('span', '', `摄入 ${kcal(row.intake)}`), el('span', '', `消耗 ${kcal(row.burn)}`));
    button.append(date, values);
    if (row.date) button.onclick = () => void selectDay(String(row.date));
    root.append(button);
  }
}
function renderRecords() {
  const loading = $('records-loading');
  if (loading) loading.hidden = !statsLoading;
  const content = $('records-content');
  if (content) content.hidden = statsLoading;
  if (!stats) {
    const empty = $('records-empty');
    if (empty) empty.hidden = statsLoading;
    return;
  }
  const empty = $('records-empty');
  if (empty) empty.hidden = true;
  renderRing(stats.selected || stats.today);
  renderChart(chartMode === 'week' ? stats.week_bars : stats.month_bars, chartMode === 'week' ? stats.week_avg : stats.month_avg);
  renderDayList(stats.day_list);
  for (const button of qsa<HTMLElement>('[data-chart]')) {
    const active = button.dataset.chart === chartMode;
    button.classList.toggle('is-active', active);
    button.setAttribute('aria-pressed', String(active));
  }
}
function renderPlan(snapshot: Snapshot) {
  const checklist = listAttribute('health_checklist');
  const valid = new Set(checklist);
  for (const item of Array.from(selectedItems)) if (!valid.has(item)) selectedItems.delete(item);
  setText('focus-text', valueText(snapshot.attributes?.health_weekly_focus) || '今天还没有重点，去对话里和小助手一起定一个。');
  setText('plan-tip', valueText(snapshot.attributes?.health_tip_today) || '先从记录一顿饭或一次散步开始。');
  const progress = Math.max(0, Math.min(100, num(snapshot.attributes?.health_progress_pct)));
  setText('plan-progress-value', `${Math.round(progress)}%`);
  const bar = $('plan-progress-bar');
  if (bar) bar.style.width = `${progress}%`;
  const root = $('checklist');
  if (!root) return;
  root.replaceChildren();
  const empty = $('checklist-empty');
  if (empty) empty.hidden = checklist.length > 0;
  for (const item of checklist) {
    const label = el('label', 'check-item');
    const box = el('input') as HTMLInputElement;
    box.type = 'checkbox';
    box.checked = selectedItems.has(item);
    box.onchange = () => {
      if (box.checked) selectedItems.add(item);
      else selectedItems.delete(item);
      renderConfirm();
    };
    label.append(box, el('span', '', item));
    root.append(label);
  }
  renderConfirm();
}
function renderConfirm() {
  const button = $<HTMLButtonElement>('plan-confirm');
  if (!button) return;
  button.disabled = selectedItems.size === 0;
  button.textContent = selectedItems.size ? `确认完成 ${selectedItems.size} 项` : '勾选已完成的行动';
}
function renderProfile(snapshot: Snapshot) {
  const height = num(snapshot.attributes?.health_height_cm);
  const weight = num(snapshot.attributes?.health_weight_kg);
  const age = num(snapshot.attributes?.health_age);
  const gender = valueText(snapshot.attributes?.health_gender) || '未填写';
  const bmi = num(snapshot.attributes?.health_bmi);
  const bmiLabel = valueText(snapshot.attributes?.health_bmi_label) || '待测量';
  const bmr = num(snapshot.attributes?.health_bmr);
  setText('profile-height', height > 0 ? `${Math.round(height * 10) / 10} cm` : '未填写');
  setText('profile-weight', weight > 0 ? `${Math.round(weight * 10) / 10} kg` : '未填写');
  setText('profile-age', age > 0 ? `${Math.round(age)} 岁` : '未填写');
  setText('profile-gender', gender);
  setText('profile-bmi', bmi > 0 ? bmi.toFixed(1) : '—');
  setText('profile-bmi-label', bmi > 0 ? bmiLabel : '填写身高体重后自动计算');
  setText('profile-bmr', bmr > 0 ? `${Math.round(bmr)} kcal` : '—');
  setText('goal-type', valueText(snapshot.attributes?.health_goal_type) || '未设定');
  setText('goal-detail', valueText(snapshot.attributes?.health_goal_detail) || '还没有设定目标，在对话里告诉小助手吧。');
  const targetWeight = num(snapshot.attributes?.health_target_weight);
  const targetHeight = num(snapshot.attributes?.health_target_height);
  setText('goal-target', [targetWeight > 0 ? `目标体重 ${targetWeight} kg` : '', targetHeight > 0 ? `目标身高 ${targetHeight} cm` : ''].filter(Boolean).join(' · ') || '暂无量化目标');
  const progress = Math.max(0, Math.min(100, num(snapshot.attributes?.health_progress_pct)));
  setText('profile-progress-value', `${Math.round(progress)}%`);
  const fill = $('profile-progress-bar');
  if (fill) fill.style.width = `${progress}%`;
}
function render(snapshot: Snapshot) {
  state = snapshot;
  if (snapshot.draft_input?.microphone_error) localError = snapshot.draft_input.microphone_error;
  setText('world-name', snapshot.world?.name || '健康生活');
  setText('today-label', snapshot.session?.time_label || '今天');
  renderMessages(snapshot);
  renderPlan(snapshot);
  renderProfile(snapshot);
  if (tab === 'records' && stats) renderRecords();
  if (snapshot.editing?.turnIndex !== editingTurn) {
    editingTurn = snapshot.editing?.turnIndex;
    if (snapshot.editing) {
      input.value = snapshot.draft_input?.value || snapshot.editing.originalContent;
      draftDirty = true;
    }
  }
  if (!draftDirty && !sending && document.activeElement !== input) input.value = snapshot.draft_input?.value || '';
  const cancel = $('cancel-edit');
  if (cancel) cancel.hidden = !snapshot.editing;
  const voice = $('voice');
  if (voice) {
    voice.setAttribute('aria-label', snapshot.draft_input?.is_recording ? '结束录音' : '开始录音');
    voice.classList.toggle('recording', !!snapshot.draft_input?.is_recording);
  }
  const attachments = $('attachments');
  if (attachments) {
    attachments.replaceChildren();
    for (const [kind, files] of [['image', snapshot.draft_input?.images], ['audio', snapshot.draft_input?.audios]] as const) {
      for (const [index, file] of (files || []).entries()) {
        const chip = el('button', 'attachment', `${file.name || kind} ×`);
        chip.type = 'button';
        chip.onclick = () => run(() => kind === 'image' ? world.actions.removeImage(index) : world.actions.removeAudio(index));
        attachments.append(chip);
      }
    }
  }
  updateStatus();
}
let toastTimer = 0;
function toast(message: string) {
  const node = $('toast');
  if (!node) return;
  node.textContent = message;
  node.classList.add('show');
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => node.classList.remove('show'), 2200);
}
function hydrate() {
  for (const button of qsa<HTMLElement>('[data-tab]')) button.addEventListener('click', () => switchTab(button.dataset.tab || 'chat'));
  for (const button of qsa<HTMLElement>('[data-chart]')) {
    button.addEventListener('click', () => {
      chartMode = button.dataset.chart === 'month' ? 'month' : 'week';
      renderRecords();
    });
  }
  $('records-sync')?.addEventListener('click', () => void syncStats());
  $('records-refresh')?.addEventListener('click', () => void loadStats(stats?.selected?.date));
  $('go-chat')?.addEventListener('click', () => switchTab('chat'));
  $('back')?.addEventListener('click', () => run(() => world.actions.navigate('home')));
  $('plan-confirm')?.addEventListener('click', () => {
    if (!selectedItems.size) return;
    const items = Array.from(selectedItems);
    void submit({ content: `【清单确认】我已完成以下行动清单事项：${items.join('；')}` }).then((ok) => {
      if (!ok) return;
      selectedItems.clear();
      renderPlan(state);
      toast('已告诉小助手');
    });
  });
  switchTab('chat');
}
function boot() {
  hydrate();
  world.subscribe((next) => {
    const first = !state.messages && !state.attributes;
    state = next;
    render(next);
    if (first && next.attributes) renderPlan(next);
  });
}
boot();
