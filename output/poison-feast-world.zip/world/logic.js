// 小恶魔的毒酒宴 —— 牌局权威结算
//
// 职责边界：
// - 玩家行动全部由本文件结算（logic.run），不经过模型。
// - 恶魔通过宿主工具调用 game.devilAct；台词永远不结算动作。
// - 牌局真相存 game.state（session KV）；给小恶魔的文本视图写进 variables.game_view，
//   世界主控提示词用 {{var:game_view}} 读取。
// - 小恶魔的银针情报只出现在 game_view，绝不出现在玩家视图与玩家日志。

const NS_GAME = "game";
const NS_VARS = "variables";
const SESSION = { scope: "session" };

const ITEM_POOL = ["needle", "spill", "incense", "strong", "herb"];
const ITEM_META = {
  needle: { label: "试毒银针", desc: "看穿当前管是毒是水，只有你知道" },
  spill: { label: "泼洒", desc: "公开倒掉当前管，不消耗行动权" },
  incense: { label: "迷魂香", desc: "对手下一次行动权直接睡过" },
  strong: { label: "烈酒", desc: "强化你下一次出杯，毒药伤害翻倍，清水也会消耗效果" },
  herb: { label: "回魂草", desc: "恢复一根命烛，不超过三根" }
};

function other(who) {
  return who === "player" ? "devil" : "player";
}

function nameOf(who) {
  return who === "player" ? "你" : "小恶魔";
}

function shuffle(list) {
  const out = list.slice();
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const tmp = out[i];
    out[i] = out[j];
    out[j] = tmp;
  }
  return out;
}

function rollItems(existing, amount) {
  const bag = existing || {};
  for (let i = 0; i < ITEM_POOL.length; i++) bag[ITEM_POOL[i]] = bag[ITEM_POOL[i]] || 0;
  const held = Object.values(bag).reduce((sum, n) => sum + n, 0);
  for (let i = 0; i < Math.min(amount || 2, 8 - held); i++) {
    const pick = ITEM_POOL[Math.floor(Math.random() * ITEM_POOL.length)];
    bag[pick] += 1;
  }
  return bag;
}

function countKinds(tubes) {
  let poison = 0;
  let water = 0;
  for (let i = 0; i < tubes.length; i++) {
    if (tubes[i] === "poison") poison += 1;
    else water += 1;
  }
  return { poison: poison, water: water };
}

function logPush(state, text) {
  state.log.push(text);
  while (state.log.length > 8) state.log.shift();
}

function clearKnows(state) {
  // 银针只对「当前管」有效；当前管变化后情报失效。
  state.player_know = null;
  state.devil_know = null;
}

// 每次装填随机 2~8 支，至少各一支毒药和清水，不使用递增难度曲线。
const MAX_TUBES = 8;

function roundTubeCount() {
  return 2 + Math.floor(Math.random() * (MAX_TUBES - 1));
}

function drawRound(state) {
  state.round += 1;
  // 开局展示序号：每次调酒都 +1。UI 靠它判断"刚换轮"，从而重播展示动画。
  state.show_seq = (state.show_seq || 0) + 1;
  // 本轮还没人动过试管：UI 用它决定"亮出药水"的展示幕是否挂着。
  // 靠 false → true 的翻转让动画重播，比在 UI 里拼奇偶 class 可靠。
  state.show_fresh = true;
  const total = roundTubeCount();
  const poisonCount = Math.floor(total / 2);
  const batch = [];
  for (let i = 0; i < poisonCount; i++) batch.push("poison");
  for (let i = 0; i < total - poisonCount; i++) batch.push("water");
  state.tubes = shuffle(batch);
  state.consumed = [];
  state.strong = false;
  state.strong_owner = null;
  state.player_asleep = false;
  state.devil_asleep = false;
  state.incense_used = false;
  const grant = 2 + Math.floor(Math.random() * 4);
  state.player_items = rollItems(state.player_items, grant);
  state.devil_items = rollItems(state.devil_items, grant);
  clearKnows(state);
  // 单人轮盘每次重新装填都由玩家先手，泼掉最后一管也是如此。
  state.turn = "player";
  logPush(
    state,
    "第 " + state.round + " 轮：小恶魔重新调了 " + total + " 支试管（" +
      poisonCount + " 毒 " + (total - poisonCount) + " 清），双方各补发 " + grant + " 件道具（库存上限 8 件）。"
  );
}

function freshState() {
  const state = {
    phase: "playing",
    winner: "",
    round: 0,
    tubes: [],
    consumed: [],
    player_candles: 3,
    devil_candles: 3,
    turn: "player",
    awaiting_devil: false,
    player_items: {},
    devil_items: {},
    incense_used: false,
    player_know: null,
    devil_know: null,
    strong: false,
    strong_owner: null,
    player_asleep: false,
    devil_asleep: false,
    // 开局展示：每次调酒推一次序号，UI 用它给"向双方亮出药水"重播动画。
    show_seq: 0,
    show_fresh: false,
    // 举杯展示：每发生一次「喝」就推进一次序号。UI 不能监听时间，只能靠序号变化
    // 触发重挂载来重播动画，所以这个计数是动画的触发器，不是展示数据。
    serve_seq: 0,
    serve_index: 0,
    serve_kind: "",
    serve_to: "",
    // 扣血演出：喝到毒药且真的熄了烛火时才推进。
    // hurt_seq 给 UI 一个"刚刚扣血"的信号（用于烛火熄灭 + 人物受击动画），
    // hurt_side_code 标明受击的是谁（1 玩家 / 2 小恶魔），hurt_amount 是熄了几根。
    hurt_seq: 0,
    hurt_side_code: 0,
    hurt_amount: 0,
    // 空杯演出：喝到清水、什么都没发生时推进，给 UI 一个"平安无事"的信号。
    null_seq: 0,
    log: [],
    last_event: "小恶魔揭开桌布，毒酒宴开始。",
    last_devil_line: ""
  };
  logPush(state, "毒酒宴开局：你 3 根命烛，小恶魔 3 根命烛。");
  drawRound(state);
  resolveSleep(state);
  state.last_event = "第 1 轮开始。先手：" + (state.turn === "player" ? "你" : "小恶魔") + "。";
  return state;
}

function resolveSleep(state) {
  if (state.phase !== "playing") return;
  // 归一化：试管架空了必须先重新调酒，否则任何行动都无法执行、牌局会卡死。
  if (state.tubes.length === 0) {
    drawRound(state);
    state.last_event = "试管喝空了，第 " + state.round + " 轮重新调酒。先手：" + (state.turn === "player" ? "你" : "小恶魔") + "。";
  }
  if (state.turn === "devil" && state.devil_asleep) {
    state.devil_asleep = false;
    logPush(state, "小恶魔被迷魂香熏晕，睡过了这一拍，行动权回到你手里。");
    state.turn = "player";
  } else if (state.turn === "player" && state.player_asleep) {
    state.player_asleep = false;
    logPush(state, "你被迷魂香熏晕，睡过了这一拍，行动权交给小恶魔。");
    state.turn = "devil";
  }
  state.awaiting_devil = state.phase === "playing" && state.turn === "devil";
}

function harm(state, target, who) {
  // 对应锯子：强化使用者的下一次出杯，目标可以是自己或对手。
  const dmg = state.strong && state.strong_owner === who ? 2 : 1;
  state.strong = false;
  state.strong_owner = null;
  const before = target === "player" ? state.player_candles : state.devil_candles;
  const after = Math.max(0, before - dmg);
  // 命烛已经烧到底就不再重复播放受击演出，否则最后一根会连闪多次。
  const really_hurt = after < before;
  if (target === "player") state.player_candles = after;
  else state.devil_candles = after;
  if (really_hurt) {
    state.hurt_seq += 1;
    state.hurt_side_code = target === "player" ? 1 : 2;
    state.hurt_amount = before - after;
  }
  return before - after;
}

function checkOver(state) {
  if (state.devil_candles <= 0) {
    state.phase = "over";
    state.winner = "player";
    state.last_event = "小恶魔的最后一根烛火熄了——你赢了，灵魂归你。";
  } else if (state.player_candles <= 0) {
    state.phase = "over";
    state.winner = "devil";
    state.last_event = "你的最后一根烛火熄了——你把灵魂押给了小恶魔。";
  }
  if (state.phase === "over") {
    state.turn = "none";
    state.awaiting_devil = false;
  }
}

// ---- 展示药水动画的数据源 ------------------------------------------------
// UI 是纯 CSS 动画 + when 分支，既没有计时器也没有可调用的 JS。
// 唯一能驱动"一次性动画重播"的办法是让 class 变化，而 class 只由 view 字段决定。
// 所以这里把"刚刚发生了什么"编码成一组 view 字段，由 UI 决定渲染哪一支试管、朝哪飞：
// serve_seq 每喝一次 +1（>0 才展示），serve_to 决定推向画面下方还是上方。

// 方向：正数=推向玩家（画面下方），负数=推向小恶魔（画面上方），0=原地泼掉。
const SERVE_DY = { player: "150px", devil: "-150px", none: "0px" };
// 倾倒角度：推向玩家时向右下方倾，推给小恶魔时向左上方倾。
const SERVE_LEAN = { player: "20deg", devil: "-20deg", none: "0deg" };
// 毒药偏红、清水偏冷蓝，UI 用它做光晕与边框色。
const SERVE_ACCENT = { poison: "#ff8098", water: "#7cc6e8" };

function markServe(state, index, kind, to) {
  state.serve_seq += 1;
  state.serve_index = index;
  state.serve_kind = kind;
  state.serve_to = to;
  // 第一支试管被动过，"亮出药水"的展示幕就该退场，把牌桌还给玩家。
  state.show_fresh = false;
}

function serveCaption(index, kind, to) {
  const kindText = kind === "poison" ? "毒药" : "清水";
  if (to === "player") return "第 " + index + " 管 · " + kindText + " → 你";
  if (to === "devil") return "第 " + index + " 管 · " + kindText + " → 小恶魔";
  return "泼掉第 " + index + " 管 · " + kindText;
}

// 所有行动的唯一入口。非法动作返回 null（调用方负责兜底）。
function applyMove(state, who, move) {
  if (state.phase !== "playing") return null;
  if (state.turn !== who) return null;
  if (move === "drink_self" || move === "drink_opponent") {
    if (!state.tubes.length) return null;
    const cur = state.tubes.shift();
    const index = state.consumed.length + 1;
    clearKnows(state);
    let text;
    let servedTo;
    if (move === "drink_self") {
      servedTo = who;
      if (cur === "poison") {
        const dmg = harm(state, who, who);
        state.consumed.push({ index: index, kind: "poison", label: "毒药", spilled: false });
        state.turn = other(who);
        text = nameOf(who) + (who === "player" ? "自己喝下第 " + index + " 管：毒药！熄了 " + dmg + " 根烛火。" : "自己灌下第 " + index + " 管：毒药！熄了 " + dmg + " 根烛火。");
      } else {
        state.consumed.push({ index: index, kind: "water", label: "清水", spilled: false });
        // 清水：谁都没事发生。推进空杯序号，让 UI 播"什么都没发生"的松弛演出。
        state.null_seq += 1;
        text = nameOf(who) + (who === "player" ? "喝下第 " + index + " 管：清水。行动权还在你手里。" : "喝下第 " + index + " 管：清水，它还能再喝一次。");
      }
    } else {
      const target = other(who);
      servedTo = target;
      state.turn = target;
      if (cur === "poison") {
        const dmg = harm(state, target, who);
        state.consumed.push({ index: index, kind: "poison", label: "毒药", spilled: false });
        text = nameOf(who) + (who === "player" ? "把第 " + index + " 管灌给小恶魔：毒药！它熄了 " + dmg + " 根烛火。" : "灌给你第 " + index + " 管：毒药！你熄了 " + dmg + " 根烛火。");
      } else {
        state.consumed.push({ index: index, kind: "water", label: "清水", spilled: false });
        state.null_seq += 1;
        text = nameOf(who) + (who === "player" ? "把第 " + index + " 管灌给小恶魔：清水……什么也没发生。" : "灌给你第 " + index + " 管：清水……什么也没发生。");
      }
    }
    state.strong = false;
    state.strong_owner = null;
    markServe(state, index, cur, servedTo);
    state.last_event = text;
    logPush(state, text);
    checkOver(state);
    resolveSleep(state);
    if (state.turn !== who) state.incense_used = false;
    return text;
  }

  // 道具：都不消耗行动权。
  const bag = who === "player" ? state.player_items : state.devil_items;
  let text = null;
  if (move === "use_needle") {
    if (!bag.needle || !state.tubes.length) return null;
    bag.needle -= 1;
    if (who === "player") state.player_know = state.tubes[0];
    else state.devil_know = state.tubes[0];
    text = nameOf(who) + (who === "player" ? "用银针探了当前管（只有你知道结果）。" : "用银针探了当前管，它知道结果但没说。");
  } else if (move === "use_spill") {
    if (!bag.spill || !state.tubes.length) return null;
    bag.spill -= 1;
    const cur = state.tubes.shift();
    const index = state.consumed.length + 1;
    state.consumed.push({ index: index, kind: cur, label: "泼掉·" + (cur === "poison" ? "毒药" : "清水"), spilled: true });
    clearKnows(state);
    markServe(state, index, cur, "none");
    text = nameOf(who) + (who === "player" ? "泼掉了第 " + index + " 管：" + (cur === "poison" ? "毒药" : "清水") + "（双方都看见了）。" : "泼掉了第 " + index + " 管：" + (cur === "poison" ? "毒药" : "清水") + "（双方都看见了）。");
  } else if (move === "use_incense") {
    if (!bag.incense || state.incense_used) return null;
    state.incense_used = true;
    bag.incense -= 1;
    if (who === "player") state.devil_asleep = true;
    else state.player_asleep = true;
    text = nameOf(who) + (who === "player" ? "点了迷魂香，下一次小恶魔获得行动权时会直接睡过。" : "点了迷魂香，下一次你获得行动权时会直接睡过。");
  } else if (move === "use_strong") {
    if (!bag.strong || state.strong) return null;
    bag.strong -= 1;
    state.strong = true;
    state.strong_owner = who;
    text = nameOf(who) + "使用烈酒：下一次出杯的毒药伤害翻倍，清水也会消耗强化。";
  } else if (move === "use_herb") {
    if (!bag.herb) return null;
    bag.herb -= 1;
    if (who === "player") state.player_candles = Math.min(3, state.player_candles + 1);
    else state.devil_candles = Math.min(3, state.devil_candles + 1);
    text = nameOf(who) + "使用回魂草，恢复一根命烛（最多三根）。";
  } else {
    return null;
  }
  state.last_event = text;
  logPush(state, text);
  resolveSleep(state);
  return text;
}

function itemList(bag) {
  const out = [];
  for (let i = 0; i < ITEM_POOL.length; i++) {
    const id = ITEM_POOL[i];
    const count = bag[id] || 0;
    if (count <= 0) continue;
    out.push({ id: id, label: ITEM_META[id].label, desc: ITEM_META[id].desc, count: count });
  }
  return out;
}

function candleArray(n) {
  const out = [];
  for (let i = 0; i < 3; i++) out.push(i < n ? 1 : 0);
  return out;
}

// 试管架视图：格子数 = 本批装填数量，前面的已倒、后面的还在架上。
// kind: "poison" | "water" | "unknown"（未探查且未倒掉的都显示 unknown，保持信息对称）。
function tubeSlots(state) {
  // 每批装填数量不同，不能写死格子数。
  const total = state.consumed.length + state.tubes.length;
  const gone = {};
  for (let i = 0; i < state.consumed.length; i++) {
    const entry = state.consumed[i];
    if (entry && typeof entry.index === "number") gone[entry.index] = entry.kind;
  }
  const out = [];
  for (let i = 0; i < total; i++) {
    const idx = i + 1;
    const remaining = idx - state.consumed.length; // 1 表示当前管
    const isGone = state.consumed.length >= idx;
    let kind = "unknown";
    if (isGone) kind = gone[idx] || "unknown";
    else if (state.player_know && remaining === 1) {
      kind = state.player_know; // 银针只在当前管有效
    }
    out.push({
      index: idx,
      // 0 已倒 / 1 在架 / 2 当前待用
      status: isGone ? 0 : (remaining === 1 ? 2 : 1),
      kind: kind,
      // 银针探知且当前管 -> 界面高亮紫色边框
      known: !isGone && !!state.player_know && remaining === 1
    });
  }
  return out;
}

function buildView(state) {
  const counts = countKinds(state.tubes);
  let hint = "";
  if (state.phase === "over") hint = state.winner === "player" ? "你赢了。" : "你输了。";
  else if (state.turn === "player") hint = "轮到你行动。";
  else if (state.awaiting_devil) hint = "轮到它了，看着就好。";
  else hint = "点「查看牌局」，看看小恶魔干了什么。";
  return {
    phase: state.phase,
    // UI 表达式不支持字符串比较，这里同时给出数值码：phase 0 未载入/1 进行中/2 结束
    phase_code: state.phase === "playing" ? 1 : 2,
    // turn 0 无/1 玩家/2 恶魔
    turn: state.turn,
    turn_code: state.phase === "over" ? 0 : state.turn === "player" ? 1 : 2,
    winner: state.winner,
    round: state.round,
    awaiting_devil: state.awaiting_devil,
    player_candles: candleArray(state.player_candles),
    devil_candles: candleArray(state.devil_candles),
    tubes_left: state.tubes.length,
    poison_left: counts.poison,
    water_left: counts.water,
    // 本轮总支数。UI 的"试管架 · N 支"与开局展示文案直接读它，
    // 写死 4 会和实际支数对不上。
    round_tubes: state.consumed.length + state.tubes.length,
    tube_slots: tubeSlots(state),
    consumed: state.consumed,
    // 本轮最后一支被动过的试管（被喝或被泼）。UI 用它给"刚刚发生"的格子
    // 挂一次性动画；恒为 0 表示本轮还没有任何试管被动作。
    last_touched_index: state.consumed.length ? state.consumed[state.consumed.length - 1].index : 0,
    player_know: state.player_know,
    // 银针情报码：0 未探查/1 毒药/2 清水
    player_know_code: state.player_know === "poison" ? 1 : state.player_know === "water" ? 2 : 0,
    strong: state.strong,
    // 烈酒归属：0 无 / 1 玩家 / 2 小恶魔。UI 据此说明这口烈酒替谁增伤。
    strong_owner_code: state.strong ? (state.strong_owner === "player" ? 1 : 2) : 0,
    devil_asleep: state.devil_asleep,
    devil_items: itemList(state.devil_items),
    devil_inventory_text: itemList(state.devil_items).map(x => x.label + "×" + x.count).join("、") || "无",
    my_items: itemList(state.player_items),
    has_items: itemList(state.player_items).length > 0,
    // 数量保留给旧 UI；新版同时公开对手的桌面库存。
    devil_item_count: Object.keys(state.devil_items).reduce(
      function (n, id) { return n + state.devil_items[id]; },
      0,
    ),
    // ---- 开局展示药水动画 ----
    // show_seq 每调一次酒 +1；>0 才展示"向双方亮出药水"，序号本身让 UI 的 class 变化、动画重播。
    show_seq: state.show_seq,
    show_active: state.show_fresh === true,
    // 本轮还没被动过试管——开局与每次换轮都为 true，第一口喝/泼掉后转 false。
    show_fresh: state.show_fresh === true,
    // ---- 展示药水动画 ----
    // serve_seq > 0 才展示举杯动画；serve_seq 本身也让 UI 的 class 变化、动画重播。
    serve_seq: state.serve_seq,
    serve_active: state.serve_seq > 0,
    serve_index: state.serve_index,
    serve_kind: state.serve_kind,
    // 0 未知/1 毒药/2 清水 —— UI 用数值码分支，避免依赖字符串比较
    serve_kind_code: state.serve_kind === "poison" ? 1 : state.serve_kind === "water" ? 2 : 0,
    serve_to: state.serve_to,
    // 0 原地泼掉/1 推向玩家/2 推给小恶魔
    serve_to_code: state.serve_to === "player" ? 1 : state.serve_to === "devil" ? 2 : 0,
    // 直接喂给 CSS 的位移、倾角与配色，省得 UI 再自己推导一遍
    serve_dy: SERVE_DY[state.serve_to] || SERVE_DY.none,
    serve_lean: SERVE_LEAN[state.serve_to] || SERVE_LEAN.none,
    serve_accent: SERVE_ACCENT[state.serve_kind] || "#b06adf",
    serve_caption: state.serve_seq > 0
      ? serveCaption(state.serve_index, state.serve_kind, state.serve_to)
      : "",
    // ---- 扣血演出 ----
    // hurt_seq > 0 才播放；奇偶两个 class 交替，保证连续扣血时动画能重播
    // （宿主按稳定 key 复用 DOM，class 不变则动画不会再次触发）。
    hurt_seq: state.hurt_seq,
    hurt_active: state.hurt_seq > 0,
    hurt_side_code: state.hurt_side_code,
    hurt_amount: state.hurt_amount,
    // ---- 空杯演出 ----
    null_seq: state.null_seq,
    null_active: state.null_seq > 0,
    // 试管移动：命中的那一格刚被取走，UI 靠它给"从架上抽走并送到对方面前"上动画
    just_moved_index: state.consumed.length ? state.consumed[state.consumed.length - 1].index : 0,
    hint: hint,
    last_event: state.last_event,
    log: state.log.slice(-5),
    over_text: state.phase === "over" ? (state.winner === "player" ? "小恶魔的烛火全熄了，灵魂归你。" : "你的烛火全熄了，灵魂归小恶魔。") : ""
  };
}

// 小恶魔的视角：只包含它有权知道的信息（公共计数 + 它自己的道具与银针情报）。
function buildGameView(state) {
  const counts = countKinds(state.tubes);
  const lines = [];
  lines.push("第 " + state.round + " 轮｜试管剩余 " + state.tubes.length + " 支：毒 " + counts.poison + " · 清 " + counts.water);
  lines.push("命烛：你 " + state.devil_candles + " 根 ｜ 玩家 " + state.player_candles + " 根");
  if (state.phase === "over") {
    lines.push("牌局已结束：" + (state.winner === "devil" ? "你赢了" : "你输了"));
  } else if (state.turn === "devil") {
    lines.push("行动权：轮到你（恶魔）");
  } else {
    lines.push("行动权：轮到玩家——你只需陪他说话，不要擅自行动");
  }
  const mine = itemList(state.devil_items);
  lines.push("你的道具：" + (mine.length ? mine.map(function (x) { return x.label + "×" + x.count; }).join("、") : "无"));
  lines.push("玩家道具：" + (itemList(state.player_items).map(x => x.label + "×" + x.count).join("、") || "无"));
  lines.push("你的银针情报：" + (state.devil_know === "poison" ? "当前管是【毒药】" : state.devil_know === "water" ? "当前管是【清水】" : "未探查"));
  lines.push("烈酒：" + (state.strong
    ? "生效中（" + (state.strong_owner === "devil" ? "你" : "玩家") + "下一次出杯毒药伤害翻倍，清水也消耗效果）"
    : "未生效"));
  lines.push("睡眠：" + (state.devil_asleep ? "你被迷魂香熏晕（本轮会睡过）" : "正常") + "｜" + (state.player_asleep ? "玩家被迷魂香熏晕" : "玩家正常"));
  if (state.log.length) {
    lines.push("最近发生：");
    for (let i = 0; i < state.log.length; i++) lines.push("- " + state.log[i]);
  }
  return lines.join("\n");
}

async function saveState(api, state) {
  await api.kv.set(NS_GAME, "state", state, SESSION);
  await api.kv.set(NS_VARS, "game_view", buildGameView(state), SESSION);
}

async function loadState(api) {
  const state = await api.kv.get(NS_GAME, "state", null, SESSION);
  if (state && typeof state === "object") return state;
  const fresh = freshState();
  await saveState(api, fresh);
  return fresh;
}

world.register("onSessionStart", async function (input, api) {
  const state = await loadState(api);
  await saveState(api, state);
  return { ok: true };
});

world.register("game.getView", async function (input, api) {
  const state = await loadState(api);
  return buildView(state);
});

world.register("game.newGame", async function (input, api) {
  const state = freshState();
  await saveState(api, state);
  return buildView(state);
});

world.register("game.playerAct", async function (input, api) {
  const state = await loadState(api);
  if (state.phase !== "playing" || state.turn !== "player") return buildView(state);
  if (!applyMove(state, "player", String(input && input.action || ""))) {
    throw new Error("动作无效，牌局没有改变。请检查行动权、道具库存及已有的道具效果。");
  }
  await saveState(api, state);
  return buildView(state);
});

world.register("game.continue", async function (input, api) {
  return buildView(await loadState(api));
});

world.register("game.devilView", async function (input, api, context) {
  if (!context || context.actor !== "agent") throw new Error("Agent-only handler");
  return { state: buildGameView(await loadState(api)) };
});

world.register("game.devilAct", async function (input, api, context) {
  if (!context || context.actor !== "agent") throw new Error("Agent-only handler");
  const state = await loadState(api);
  if (state.phase !== "playing" || state.turn !== "devil") {
    return { applied: false, turn_ended: true, state: buildGameView(state) };
  }
  const result = applyMove(state, "devil", String(input && input.action || ""));
  if (!result) return { applied: false, error: "Invalid action; nothing changed.", state: buildGameView(state) };
  await saveState(api, state);
  return { applied: true, turn_ended: state.phase !== "playing" || state.turn !== "devil", state: buildGameView(state) };
});
