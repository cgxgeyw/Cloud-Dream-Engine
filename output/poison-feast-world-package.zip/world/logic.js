// 小恶魔的毒酒宴 —— 牌局权威结算
//
// 职责边界：
// - 玩家行动全部由本文件结算（logic.run），不经过模型。
// - 恶魔行动由模型在台词末尾用【行动】宣言短语宣布，turn_completed 里解析并结算。
// - 牌局真相存 game.state（session KV）；给小恶魔的文本视图写进 variables.game_view，
//   世界主控提示词用 {{var:game_view}} 读取。
// - 小恶魔的银针情报只出现在 game_view，绝不出现在玩家视图与玩家日志。

const NS_GAME = "game";
const NS_VARS = "variables";
const SESSION = { scope: "session" };

const ITEM_POOL = ["needle", "spill", "incense", "strong"];
const ITEM_META = {
  needle: { label: "试毒银针", desc: "看穿当前管是毒是水，只有你知道" },
  spill: { label: "泼洒", desc: "公开倒掉当前管，不消耗行动权" },
  incense: { label: "迷魂香", desc: "对手下一次行动权直接睡过" },
  strong: { label: "烈酒", desc: "下一管毒药熄灭两根烛火（双方可见）" }
};

function other(who) {
  return who === "player" ? "devil" : "player";
}

function nameOf(who) {
  return who === "player" ? "你" : "小恶魔";
}

function shuffle(list) {
  const out = list.slice();
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const tmp = out[i];
    out[i] = out[j];
    out[j] = tmp;
  }
  return out;
}

function rollItems() {
  const bag = {};
  for (let i = 0; i < ITEM_POOL.length; i++) bag[ITEM_POOL[i]] = 0;
  for (let i = 0; i < 2; i++) {
    const pick = ITEM_POOL[Math.floor(Math.random() * ITEM_POOL.length)];
    bag[pick] += 1;
  }
  return bag;
}

function countKinds(tubes) {
  let poison = 0;
  let water = 0;
  for (let i = 0; i < tubes.length; i++) {
    if (tubes[i] === "poison") poison += 1;
    else water += 1;
  }
  return { poison: poison, water: water };
}

function logPush(state, text) {
  state.log.push(text);
  while (state.log.length > 8) state.log.shift();
}

function clearKnows(state) {
  // 银针只对「当前管」有效；当前管变化后情报失效。
  state.player_know = null;
  state.devil_know = null;
}

function drawRound(state) {
  state.round += 1;
  state.tubes = shuffle(["poison", "poison", "water", "water"]);
  state.consumed = [];
  state.strong = false;
  state.player_items = rollItems();
  state.devil_items = rollItems();
  clearKnows(state);
  state.turn = Math.random() < 0.5 ? "player" : "devil";
  logPush(state, "第 " + state.round + " 轮：小恶魔重新调了 4 支试管（2 毒 2 清），双方各得 2 件道具。");
}

function freshState() {
  const state = {
    phase: "playing",
    winner: "",
    round: 0,
    tubes: [],
    consumed: [],
    player_candles: 3,
    devil_candles: 3,
    turn: "player",
    awaiting_devil: false,
    player_items: rollItems(),
    devil_items: rollItems(),
    player_know: null,
    devil_know: null,
    strong: false,
    player_asleep: false,
    devil_asleep: false,
    log: [],
    last_event: "小恶魔揭开桌布，毒酒宴开始。",
    last_devil_line: ""
  };
  logPush(state, "毒酒宴开局：你 3 根命烛，小恶魔 3 根命烛。");
  drawRound(state);
  resolveSleep(state);
  state.last_event = "第 1 轮开始。先手：" + (state.turn === "player" ? "你" : "小恶魔") + "。";
  return state;
}

function resolveSleep(state) {
  if (state.phase !== "playing") return;
  // 归一化：试管架空了必须先重新调酒，否则任何行动都无法执行、牌局会卡死。
  if (state.tubes.length === 0) {
    drawRound(state);
    state.last_event = "试管喝空了，第 " + state.round + " 轮重新调酒。先手：" + (state.turn === "player" ? "你" : "小恶魔") + "。";
  }
  if (state.turn === "devil" && state.devil_asleep) {
    state.devil_asleep = false;
    logPush(state, "小恶魔被迷魂香熏晕，睡过了这一拍，行动权回到你手里。");
    state.turn = "player";
  } else if (state.turn === "player" && state.player_asleep) {
    state.player_asleep = false;
    logPush(state, "你被迷魂香熏晕，睡过了这一拍，行动权交给小恶魔。");
    state.turn = "devil";
  }
  state.awaiting_devil = state.phase === "playing" && state.turn === "devil";
}

function harm(state, target) {
  const dmg = state.strong ? 2 : 1;
  state.strong = false;
  if (target === "player") state.player_candles = Math.max(0, state.player_candles - dmg);
  else state.devil_candles = Math.max(0, state.devil_candles - dmg);
  return dmg;
}

function checkOver(state) {
  if (state.devil_candles <= 0) {
    state.phase = "over";
    state.winner = "player";
    state.last_event = "小恶魔的最后一根烛火熄了——你赢了，灵魂归你。";
  } else if (state.player_candles <= 0) {
    state.phase = "over";
    state.winner = "devil";
    state.last_event = "你的最后一根烛火熄了——你把灵魂押给了小恶魔。";
  }
}

function advanceIfEmpty(state) {
  if (state.phase !== "playing") return;
  if (state.tubes.length === 0) {
    drawRound(state);
    state.last_event = "试管喝空了，第 " + state.round + " 轮重新调酒。先手：" + (state.turn === "player" ? "你" : "小恶魔") + "。";
  }
}

// 所有行动的唯一入口。非法动作返回 null（调用方负责兜底）。
function applyMove(state, who, move) {
  if (state.phase !== "playing") return null;
  if (move === "drink_self" || move === "drink_opponent") {
    if (!state.tubes.length) return null;
    const cur = state.tubes.shift();
    const index = state.consumed.length + 1;
    clearKnows(state);
    let text;
    if (move === "drink_self") {
      if (cur === "poison") {
        const dmg = harm(state, who);
        state.consumed.push({ index: index, kind: "poison", label: "毒药", spilled: false });
        state.turn = other(who);
        text = nameOf(who) + (who === "player" ? "自己喝下第 " + index + " 管：毒药！熄了 " + dmg + " 根烛火。" : "自己灌下第 " + index + " 管：毒药！熄了 " + dmg + " 根烛火。");
      } else {
        state.consumed.push({ index: index, kind: "water", label: "清水", spilled: false });
        text = nameOf(who) + (who === "player" ? "喝下第 " + index + " 管：清水。行动权还在你手里。" : "喝下第 " + index + " 管：清水，它还能再喝一次。");
      }
    } else {
      const target = other(who);
      state.turn = target;
      if (cur === "poison") {
        const dmg = harm(state, target);
        state.consumed.push({ index: index, kind: "poison", label: "毒药", spilled: false });
        text = nameOf(who) + (who === "player" ? "把第 " + index + " 管灌给小恶魔：毒药！它熄了 " + dmg + " 根烛火。" : "灌给你第 " + index + " 管：毒药！你熄了 " + dmg + " 根烛火。");
      } else {
        state.consumed.push({ index: index, kind: "water", label: "清水", spilled: false });
        text = nameOf(who) + (who === "player" ? "把第 " + index + " 管灌给小恶魔：清水……什么也没发生。" : "灌给你第 " + index + " 管：清水……什么也没发生。");
      }
    }
    state.last_event = text;
    logPush(state, text);
    checkOver(state);
    advanceIfEmpty(state);
    resolveSleep(state);
    return text;
  }

  // 道具：都不消耗行动权。
  const bag = who === "player" ? state.player_items : state.devil_items;
  let text = null;
  if (move === "use_needle") {
    if (!bag.needle || !state.tubes.length) return null;
    bag.needle -= 1;
    if (who === "player") state.player_know = state.tubes[0];
    else state.devil_know = state.tubes[0];
    text = nameOf(who) + (who === "player" ? "用银针探了当前管（只有你知道结果）。" : "用银针探了当前管，它知道结果但没说。");
  } else if (move === "use_spill") {
    if (!bag.spill || !state.tubes.length) return null;
    bag.spill -= 1;
    const cur = state.tubes.shift();
    const index = state.consumed.length + 1;
    state.consumed.push({ index: index, kind: cur, label: "泼掉·" + (cur === "poison" ? "毒药" : "清水"), spilled: true });
    state.player_know = cur;
    state.devil_know = cur;
    text = nameOf(who) + (who === "player" ? "泼掉了第 " + index + " 管：" + (cur === "poison" ? "毒药" : "清水") + "（双方都看见了）。" : "泼掉了第 " + index + " 管：" + (cur === "poison" ? "毒药" : "清水") + "（双方都看见了）。");
  } else if (move === "use_incense") {
    if (!bag.incense) return null;
    bag.incense -= 1;
    if (who === "player") state.devil_asleep = true;
    else state.player_asleep = true;
    text = nameOf(who) + (who === "player" ? "点了迷魂香，下一次小恶魔获得行动权时会直接睡过。" : "点了迷魂香，下一次你获得行动权时会直接睡过。");
  } else if (move === "use_strong") {
    if (!bag.strong) return null;
    bag.strong -= 1;
    state.strong = true;
    text = nameOf(who) + (who === "player" ? "灌下烈酒：下一管毒药将熄灭两根烛火（双方可见）。" : "灌下烈酒：下一管毒药将熄灭两根烛火（双方可见）。");
  } else {
    return null;
  }
  state.last_event = text;
  logPush(state, text);
  resolveSleep(state);
  return text;
}

function itemList(bag) {
  const out = [];
  for (let i = 0; i < ITEM_POOL.length; i++) {
    const id = ITEM_POOL[i];
    const count = bag[id] || 0;
    if (count <= 0) continue;
    out.push({ id: id, label: ITEM_META[id].label, desc: ITEM_META[id].desc, count: count });
  }
  return out;
}

function candleArray(n) {
  const out = [];
  for (let i = 0; i < 3; i++) out.push(i < n ? 1 : 0);
  return out;
}

// 试管架视图：4 个格子，前面的已倒、后面的还在架上。
// kind: "poison" | "water" | "unknown"（未探查且未倒掉的都显示 unknown，保持信息对称）。
function tubeSlots(state) {
  const total = 4;
  const gone = {};
  for (let i = 0; i < state.consumed.length; i++) {
    const entry = state.consumed[i];
    if (entry && typeof entry.index === "number") gone[entry.index] = entry.kind;
  }
  const out = [];
  for (let i = 0; i < total; i++) {
    const idx = i + 1;
    const remaining = idx - state.consumed.length; // 1 表示当前管
    const isGone = state.consumed.length >= idx;
    let kind = "unknown";
    if (isGone) kind = gone[idx] || "unknown";
    else if (state.player_know && remaining === 1) {
      kind = state.player_know; // 银针只在当前管有效
    }
    out.push({
      index: idx,
      // 0 已倒 / 1 在架 / 2 当前待用
      status: isGone ? 0 : (remaining === 1 ? 2 : 1),
      kind: kind,
      // 银针探知且当前管 -> 界面高亮紫色边框
      known: !isGone && !!state.player_know && remaining === 1
    });
  }
  return out;
}

function buildView(state) {
  const counts = countKinds(state.tubes);
  let hint = "";
  if (state.phase === "over") hint = state.winner === "player" ? "你赢了。" : "你输了。";
  else if (state.turn === "player") hint = "轮到你行动。";
  else if (state.awaiting_devil) hint = "把酒盏推向小恶魔，看它怎么选。";
  else hint = "点「查看牌局」，看看小恶魔干了什么。";
  return {
    phase: state.phase,
    // UI 表达式不支持字符串比较，这里同时给出数值码：phase 0 未载入/1 进行中/2 结束
    phase_code: state.phase === "playing" ? 1 : 2,
    // turn 0 无/1 玩家/2 恶魔
    turn: state.turn,
    turn_code: state.turn === "player" ? 1 : 2,
    winner: state.winner,
    round: state.round,
    awaiting_devil: state.awaiting_devil,
    player_candles: candleArray(state.player_candles),
    devil_candles: candleArray(state.devil_candles),
    tubes_left: state.tubes.length,
    poison_left: counts.poison,
    water_left: counts.water,
    tube_slots: tubeSlots(state),
    consumed: state.consumed,
    player_know: state.player_know,
    // 银针情报码：0 未探查/1 毒药/2 清水
    player_know_code: state.player_know === "poison" ? 1 : state.player_know === "water" ? 2 : 0,
    strong: state.strong,
    devil_asleep: state.devil_asleep,
    my_items: itemList(state.player_items),
    has_items: itemList(state.player_items).length > 0,
    hint: hint,
    last_event: state.last_event,
    log: state.log.slice(-5),
    over_text: state.phase === "over" ? (state.winner === "player" ? "小恶魔的烛火全熄了，灵魂归你。" : "你的烛火全熄了，灵魂归小恶魔。") : ""
  };
}

// 小恶魔的视角：只包含它有权知道的信息（公共计数 + 它自己的道具与银针情报）。
function buildGameView(state) {
  const counts = countKinds(state.tubes);
  const lines = [];
  lines.push("第 " + state.round + " 轮｜试管剩余 " + state.tubes.length + " 支：毒 " + counts.poison + " · 清 " + counts.water);
  lines.push("命烛：你 " + state.devil_candles + " 根 ｜ 玩家 " + state.player_candles + " 根");
  if (state.phase === "over") {
    lines.push("牌局已结束：" + (state.winner === "devil" ? "你赢了" : "你输了"));
  } else if (state.turn === "devil") {
    lines.push("行动权：轮到你（恶魔）");
  } else {
    lines.push("行动权：轮到玩家——你只需陪他说话，不要擅自行动");
  }
  const mine = itemList(state.devil_items);
  lines.push("你的道具：" + (mine.length ? mine.map(function (x) { return x.label + "×" + x.count; }).join("、") : "无"));
  lines.push("你的银针情报：" + (state.devil_know === "poison" ? "当前管是【毒药】" : state.devil_know === "water" ? "当前管是【清水】" : "未探查"));
  lines.push("烈酒：" + (state.strong ? "生效中（下一管毒药双倍伤害）" : "未生效"));
  lines.push("睡眠：" + (state.devil_asleep ? "你被迷魂香熏晕（本轮会睡过）" : "正常") + "｜" + (state.player_asleep ? "玩家被迷魂香熏晕" : "玩家正常"));
  if (state.log.length) {
    lines.push("最近发生：");
    for (let i = 0; i < state.log.length; i++) lines.push("- " + state.log[i]);
  }
  return lines.join("\n");
}

async function saveState(api, state) {
  await api.kv.set(NS_GAME, "state", state, SESSION);
  await api.kv.set(NS_VARS, "game_view", buildGameView(state), SESSION);
}

async function loadState(api) {
  const state = await api.kv.get(NS_GAME, "state", null, SESSION);
  return state && typeof state === "object" ? state : freshState();
}

function messageText(message) {
  const content = message && message.content;
  if (typeof content === "string") return content;
  if (content && typeof content === "object") {
    if (typeof content.text === "string") return content.text;
    if (typeof content.content === "string") return content.content;
  }
  return "";
}

// 小恶魔的行动宣言解析：从本回合最后一条恶魔发言里找【行动】短语。
function parseDevilMove(messages) {
  const list = Array.isArray(messages) ? messages : [];
  let last = null;
  for (let i = 0; i < list.length; i++) {
    const message = list[i];
    if (!message || message.role !== "agent") continue;
    last = message;
  }
  if (!last) return null;
  const text = messageText(last);
  if (!text) return null;
  const table = [
    ["【行动】使用银针", "use_needle"],
    ["【行动】泼洒", "use_spill"],
    ["【行动】使用迷魂香", "use_incense"],
    ["【行动】使用烈酒", "use_strong"],
    ["【行动】自己喝下", "drink_self"],
    ["【行动】灌给对方", "drink_opponent"]
  ];
  for (let i = 0; i < table.length; i++) {
    if (text.indexOf(table[i][0]) >= 0) return { move: table[i][1], line: text };
  }
  return { move: null, line: text };
}

world.register("onSessionStart", async function (input, api) {
  const state = freshState();
  await saveState(api, state);
  return { ok: true };
});

world.register("game.getView", async function (input, api) {
  const state = await loadState(api);
  return buildView(state);
});

world.register("game.newGame", async function (input, api) {
  const state = freshState();
  await saveState(api, state);
  return buildView(state);
});

world.register("game.playerAct", async function (input, api) {
  const state = await loadState(api);
  if (state.phase !== "playing") return buildView(state);
  if (state.turn !== "player") return buildView(state);
  const move = String((input && input.action) || "");
  const applied = applyMove(state, "player", move);
  if (applied) {
    await saveState(api, state);
    return buildView(state);
  }
  // 非法动作：自动降级为「灌给对方」，并留痕。
  const fallback = applyMove(state, "player", "drink_opponent");
  const note = "（动作无效，自动改为灌给对方）";
  state.last_event = note;
  await saveState(api, state);
  const view = buildView(state);
  view.note = fallback ? note : "";
  return view;
});

world.register("onTurn", async function (input, api) {
  const state = await loadState(api);
  if (state.phase !== "playing") return;
  if (!state.awaiting_devil || state.turn !== "devil") return;

  // 迷魂香在结算之前判定：沉睡的小恶魔无法行动，这一拍直接跳过。
  if (state.devil_asleep) {
    state.devil_asleep = false;
    state.turn = "player";
    state.awaiting_devil = false;
    state.last_event = "小恶魔被迷魂香熏晕，握着酒盏的手停在半空——这一拍它动不了。";
    logPush(state, "小恶魔被迷魂香熏晕，睡过了这一拍。");
    await saveState(api, state);
    return;
  }

  const parsed = parseDevilMove(input && input.messages);
  let applied = null;
  if (parsed && parsed.move) {
    applied = applyMove(state, "devil", parsed.move);
  }
  if (!applied) {
    // 宣言缺失或非法：兜底为「灌给玩家」，保证牌局永远向前推进。
    applied = applyMove(state, "devil", "drink_opponent");
    if (applied) state.last_event = applied + "（它没打出合法宣言，这杯算你头上。）";
  }
  if (!applied) {
    // 极端兜底：牌局无法推进时重新调酒，绝不把行动权卡死在这里。
    drawRound(state);
    state.last_event = "第 " + state.round + " 轮重新调酒。先手：" + (state.turn === "player" ? "你" : "小恶魔") + "。";
  }
  await saveState(api, state);
});
